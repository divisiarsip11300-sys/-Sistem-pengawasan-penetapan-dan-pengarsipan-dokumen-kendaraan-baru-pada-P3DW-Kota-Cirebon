import { KbmRecord } from '../types/archive';
import { calculateJatuhTempo, getTodayDateString } from '../utils/formatters';

const today = getTodayDateString();

// Helper to create date relative to today
function getDateOffset(daysOffset: number): string {
  const d = new Date();
  d.setDate(d.getDate() + daysOffset);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export const INITIAL_KBM_RECORDS: KbmRecord[] = [
  {
    id: 'kbm-crb-001',
    tgl: today,
    nopol: 'E 2108 BQ',
    nama: 'PT. MAJU BERSAMA MOTOR CIREBON',
    tglFaktur: getDateOffset(-5),
    tglBayar: today,
    jatemFakt: calculateJatuhTempo(getDateOffset(-5), 30),
    rumusHari: 30,
    roda: 'R4',
    transaksi: 'CKD',
    plat: '1',
    statusBayar: 'SUDAH BAYAR',
    evident: '',
    evidentName: 'FAKTUR_E2108BQ.JPG',
    linkFile: 'D:\\ARSIP_SAMSAT_CIREBON\\2026\\KBM_BARU\\E_2108_BQ.pdf',
    note: 'Lengkap. Faktur ATPM Astra Daihatsu Cirebon, berkas cetak fisik sudah diverifikasi loket 1.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'kbm-crb-002',
    tgl: today,
    nopol: 'E 4392 DAA',
    nama: 'H. RADEN SUTISNA WIRANATA',
    tglFaktur: getDateOffset(-12),
    tglBayar: today,
    jatemFakt: calculateJatuhTempo(getDateOffset(-12), 30),
    rumusHari: 30,
    roda: 'R2',
    transaksi: 'CKD',
    plat: '1',
    statusBayar: 'SUDAH BAYAR',
    evident: '',
    evidentName: 'STNK_E4392DAA.JPG',
    linkFile: 'D:\\ARSIP_SAMSAT_CIREBON\\2026\\KBM_BARU\\E_4392_DAA.pdf',
    note: 'Pendaftaran sepeda motor Honda Vario 160 baru, pembayaran tunai kasir Bank bjb Samsat.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'kbm-crb-003',
    tgl: today,
    nopol: 'E 8721 KS',
    nama: 'CV. SUMBER REJEKI LOGISTIK',
    tglFaktur: getDateOffset(-28),
    tglBayar: '',
    jatemFakt: calculateJatuhTempo(getDateOffset(-28), 30),
    rumusHari: 30,
    roda: 'R4',
    transaksi: 'EX DUMP',
    plat: '2',
    statusBayar: 'BELUM BAYAR',
    evident: '',
    evidentName: 'EVIDENT_DUMP_8721.JPG',
    linkFile: 'D:\\ARSIP_SAMSAT_CIREBON\\2026\\KBM_BARU\\E_8721_KS.pdf',
    note: 'Menunggu rekomendasi izin trayek Dishub Kota Cirebon & bukti pelunasan lelang ex-dumping.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'kbm-crb-004',
    tgl: today,
    nopol: 'E 1002 YN',
    nama: 'DINAS KESEHATAN KOTA CIREBON',
    tglFaktur: getDateOffset(-15),
    tglBayar: today,
    jatemFakt: calculateJatuhTempo(getDateOffset(-15), 30),
    rumusHari: 30,
    roda: 'R4',
    transaksi: 'CKD',
    plat: '3',
    statusBayar: 'SUDAH BAYAR',
    evident: '',
    evidentName: 'AMBULANS_DINKES_E1002YN.JPG',
    linkFile: 'D:\\ARSIP_SAMSAT_CIREBON\\2026\\KBM_BARU\\E_1002_YN.pdf',
    note: 'Unit Ambulans Pelayanan Kesehatan Keliling Pemkot Cirebon, Surat Perintah Kerja APBD.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'kbm-crb-005',
    tgl: getDateOffset(-1),
    nopol: 'E 5519 WA',
    nama: 'ANDI KURNIAWAN, S.T.',
    tglFaktur: getDateOffset(-14),
    tglBayar: '',
    jatemFakt: calculateJatuhTempo(getDateOffset(-14), 30),
    rumusHari: 30,
    roda: 'R4',
    transaksi: 'LISTRIK/HYB',
    plat: '1',
    statusBayar: 'BELUM BAYAR',
    evident: '',
    evidentName: 'IONIQ5_E5519WA.JPG',
    linkFile: 'D:\\ARSIP_SAMSAT_CIREBON\\2026\\KBM_BARU\\E_5519_WA.pdf',
    note: 'Pajak Kendaraan Listrik (PKB 0% BBNKB), menunggu verifikasi sertifikat uji tipe (SUT) Kemenhub.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'kbm-crb-006',
    tgl: getDateOffset(-1),
    nopol: 'E 3320 XA',
    nama: 'PT. SURYA MOTOR INDAH',
    tglFaktur: getDateOffset(-40),
    tglBayar: '',
    jatemFakt: calculateJatuhTempo(getDateOffset(-40), 30),
    rumusHari: 30,
    roda: 'R4',
    transaksi: 'CBU',
    plat: '1',
    statusBayar: 'BELUM BAYAR',
    evident: '',
    evidentName: 'PIB_BEACUKAI_E3320XA.JPG',
    linkFile: 'D:\\ARSIP_SAMSAT_CIREBON\\2026\\KBM_BARU\\E_3320_XA.pdf',
    note: 'Faktur CBU lewat 30 hari. Menunggu konfirmasi denda keterlambatan BBNKB I dari Bapenda Jabar.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'kbm-crb-007',
    tgl: getDateOffset(-2),
    nopol: 'E 6640 PL',
    nama: 'KOPERASI ANGKUTAN KOTA CIREBON',
    tglFaktur: getDateOffset(-8),
    tglBayar: getDateOffset(-2),
    jatemFakt: calculateJatuhTempo(getDateOffset(-8), 30),
    rumusHari: 30,
    roda: 'R3',
    transaksi: 'CKD',
    plat: '2',
    statusBayar: 'SUDAH BAYAR',
    evident: '',
    evidentName: 'TRISEDA_E6640PL.JPG',
    linkFile: 'D:\\ARSIP_SAMSAT_CIREBON\\2026\\KBM_BARU\\E_6640_PL.pdf',
    note: 'Kendaraan roda 3 niaga angkutan barang UMKM Pasar Kanoman Cirebon, BBNKB lunas.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'kbm-crb-008',
    tgl: getDateOffset(-3),
    nopol: 'E 9012 AZ',
    nama: 'BAMBANG HERMANTO',
    tglFaktur: getDateOffset(-10),
    tglBayar: getDateOffset(-3),
    jatemFakt: calculateJatuhTempo(getDateOffset(-10), 30),
    rumusHari: 30,
    roda: 'R4',
    transaksi: 'GIIAS',
    plat: '1',
    statusBayar: 'SUDAH BAYAR',
    evident: '',
    evidentName: 'SPK_GIIAS_E9012AZ.JPG',
    linkFile: 'D:\\ARSIP_SAMSAT_CIREBON\\2026\\KBM_BARU\\E_9012_AZ.pdf',
    note: 'Pemesanan unit pameran GIIAS 2026, dokumen delivery order dan surat tanda coba kendaraan sah.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'kbm-crb-009',
    tgl: getDateOffset(-4),
    nopol: 'E 4401 CC',
    nama: 'KECAMATAN KEJAKSAN KOTA CIREBON',
    tglFaktur: getDateOffset(-20),
    tglBayar: getDateOffset(-4),
    jatemFakt: calculateJatuhTempo(getDateOffset(-20), 30),
    rumusHari: 30,
    roda: 'R2',
    transaksi: 'CKD',
    plat: '3',
    statusBayar: 'SUDAH BAYAR',
    evident: '',
    evidentName: 'R2_DINAS_E4401CC.JPG',
    linkFile: 'D:\\ARSIP_SAMSAT_CIREBON\\2026\\KBM_BARU\\E_4401_CC.pdf',
    note: 'Sepeda motor operasional kelurahan, anggaran APBD perubahan, plat merah terbit.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'kbm-crb-010',
    tgl: getDateOffset(-5),
    nopol: 'E 7789 MM',
    nama: 'PT. CIREBON ELECTRIC POWER',
    tglFaktur: getDateOffset(-18),
    tglBayar: '',
    jatemFakt: calculateJatuhTempo(getDateOffset(-18), 30),
    rumusHari: 30,
    roda: 'R4',
    transaksi: 'LISTRIK/HYB',
    plat: '1',
    statusBayar: 'BELUM BAYAR',
    evident: '',
    evidentName: 'EV_BUS_E7789MM.JPG',
    linkFile: 'D:\\ARSIP_SAMSAT_CIREBON\\2026\\KBM_BARU\\E_7789_MM.pdf',
    note: 'Menunggu pencocokan nomor rangka fisik (gesekan) oleh petugas cek fisik Samsat Kota Cirebon.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'kbm-crb-011',
    tgl: getDateOffset(-8),
    nopol: 'E 1155 ZZ',
    nama: 'HJ. NURJANAH DEWI',
    tglFaktur: getDateOffset(-15),
    tglBayar: getDateOffset(-8),
    jatemFakt: calculateJatuhTempo(getDateOffset(-15), 30),
    rumusHari: 30,
    roda: 'R2',
    transaksi: 'CKD',
    plat: '1',
    statusBayar: 'SUDAH BAYAR',
    evident: '',
    evidentName: 'R2_E1155ZZ.JPG',
    linkFile: 'D:\\ARSIP_SAMSAT_CIREBON\\2026\\KBM_BARU\\E_1155_ZZ.pdf',
    note: 'Yamaha NMAX Turbo baru, pembayaran lunas via QRIS bjb.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'kbm-crb-012',
    tgl: getDateOffset(-15),
    nopol: 'E 3820 KL',
    nama: 'CV. BINTANG PANJALU',
    tglFaktur: getDateOffset(-35),
    tglBayar: '',
    jatemFakt: calculateJatuhTempo(getDateOffset(-35), 30),
    rumusHari: 30,
    roda: 'R4',
    transaksi: 'CKD',
    plat: '2',
    statusBayar: 'BELUM BAYAR',
    evident: '',
    evidentName: 'DUMP_E3820KL.JPG',
    linkFile: 'D:\\ARSIP_SAMSAT_CIREBON\\2026\\KBM_BARU\\E_3820_KL.pdf',
    note: 'Pemohon menunda pembayaran karena menunggu pencairan termin leasing pembiayaan.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }
];

export const STORAGE_KEY = 'kbm_baru_p3dw_cirebon_records_v1';

export function loadStoredRecords(): KbmRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_KBM_RECORDS));
      return INITIAL_KBM_RECORDS;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
    return INITIAL_KBM_RECORDS;
  } catch (err) {
    console.warn('Failed to load local records, using default', err);
    return INITIAL_KBM_RECORDS;
  }
}

export function saveStoredRecords(records: KbmRecord[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
  } catch (err) {
    console.error('Failed to save records to localStorage', err);
  }
}
