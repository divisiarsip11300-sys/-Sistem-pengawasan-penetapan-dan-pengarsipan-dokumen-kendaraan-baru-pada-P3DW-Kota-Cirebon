import React, { useState, useMemo } from 'react';
import { 
  CheckCircle2, 
  XCircle, 
  TrendingUp, 
  Calendar, 
  Layers, 
  Car, 
  ArrowRight,
  ShieldCheck,
  AlertTriangle,
  FileText,
  Search,
  Filter
} from 'lucide-react';
import { KbmRecord } from '../types/archive';
import { getTodayDateString, formatIndoDate, getPlatLabel, getRodaLabel } from '../utils/formatters';
import heroImage from '../assets/images/archive_kbm_hero_1792736672938.jpg';

interface DashboardViewProps {
  records: KbmRecord[];
  onNavigateToUnpaid: () => void;
  onNavigateToArchive: () => void;
  onOpenNewModal: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  records,
  onNavigateToUnpaid,
  onNavigateToArchive,
  onOpenNewModal,
}) => {
  const todayStr = getTodayDateString();

  // Date filter for entry counting
  const [selectedEntryDateFilter, setSelectedEntryDateFilter] = useState<'all' | 'today' | 'last7'>('all');
  const [customSearchNopol, setCustomSearchNopol] = useState<string>('');

  // Filtered records for quick counting
  const filteredRecords = useMemo(() => {
    return records.filter(r => {
      if (selectedEntryDateFilter === 'today' && r.tgl !== todayStr) return false;
      if (selectedEntryDateFilter === 'last7') {
        const entryTime = new Date(r.tgl).getTime();
        const sevenDaysAgo = new Date().getTime() - 7 * 24 * 60 * 60 * 1000;
        if (entryTime < sevenDaysAgo) return false;
      }
      if (customSearchNopol) {
        const query = customSearchNopol.toLowerCase().trim();
        const match = r.nopol.toLowerCase().includes(query) ||
                      r.nama.toLowerCase().includes(query) ||
                      r.transaksi.toLowerCase().includes(query) ||
                      r.note.toLowerCase().includes(query);
        if (!match) return false;
      }
      return true;
    });
  }, [records, selectedEntryDateFilter, todayStr, customSearchNopol]);

  // Overall metrics
  const totalCount = records.length;
  const paidCount = records.filter(r => r.statusBayar === 'SUDAH BAYAR').length;
  const unpaidCount = records.filter(r => r.statusBayar === 'BELUM BAYAR' || r.statusBayar === 'DIBATALKAN').length;
  const paidPercentage = totalCount > 0 ? Math.round((paidCount / totalCount) * 100) : 0;
  const unpaidPercentage = 100 - paidPercentage;

  // Today specific metrics
  const todayRegistered = records.filter(r => r.tgl === todayStr).length;
  const todayPaid = records.filter(r => r.tglBayar === todayStr && r.statusBayar === 'SUDAH BAYAR').length;

  // Grouping counting by Tgl Entri
  const countingByDate = useMemo(() => {
    const map = new Map<string, { total: number; paid: number; unpaid: number }>();
    records.forEach(r => {
      const dateKey = r.tgl || 'Tanpa Tanggal';
      const cur = map.get(dateKey) || { total: 0, paid: 0, unpaid: 0 };
      cur.total += 1;
      if (r.statusBayar === 'SUDAH BAYAR') {
        cur.paid += 1;
      } else {
        cur.unpaid += 1;
      }
      map.set(dateKey, cur);
    });

    return Array.from(map.entries())
      .map(([date, data]) => ({
        date,
        ...data,
        rate: Math.round((data.paid / data.total) * 100)
      }))
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [records]);

  // Comparison by Roda (R2, R3, R4)
  const comparisonByRoda = useMemo(() => {
    const items: Array<{ key: 'R2' | 'R3' | 'R4'; label: string; total: number; paid: number; unpaid: number }> = [
      { key: 'R2', label: 'R2 (Sepeda Motor)', total: 0, paid: 0, unpaid: 0 },
      { key: 'R3', label: 'R3 (Tiga Roda)', total: 0, paid: 0, unpaid: 0 },
      { key: 'R4', label: 'R4 (Roda 4 / Mobil)', total: 0, paid: 0, unpaid: 0 },
    ];

    records.forEach(r => {
      const target = items.find(i => i.key === r.roda);
      if (target) {
        target.total += 1;
        if (r.statusBayar === 'SUDAH BAYAR') target.paid += 1;
        else target.unpaid += 1;
      }
    });

    return items;
  }, [records]);

  // Comparison by Transaksi (CKD, CBU, GIIAS, EX DUMP, LISTRIK/HYB)
  const comparisonByTransaksi = useMemo(() => {
    const transList = ['CKD', 'CBU', 'GIIAS', 'EX DUMP', 'LISTRIK/HYB'] as const;
    return transList.map(type => {
      const recs = records.filter(r => r.transaksi === type);
      const paid = recs.filter(r => r.statusBayar === 'SUDAH BAYAR').length;
      return {
        transaksi: type,
        total: recs.length,
        paid,
        unpaid: recs.length - paid,
        rate: recs.length > 0 ? Math.round((paid / recs.length) * 100) : 0,
      };
    });
  }, [records]);

  // Comparison by Plat (1, 2, 3)
  const comparisonByPlat = useMemo(() => {
    const plats = [
      { code: '1', name: 'Plat 1 (Hitam/Pribadi)' },
      { code: '2', name: 'Plat 2 (Kuning/Angkutan)' },
      { code: '3', name: 'Plat 3 (Merah/Dinas)' }
    ];
    return plats.map(p => {
      const recs = records.filter(r => r.plat === p.code);
      const paid = recs.filter(r => r.statusBayar === 'SUDAH BAYAR').length;
      return {
        plat: p.code,
        label: p.name,
        total: recs.length,
        paid,
        unpaid: recs.length - paid,
        rate: recs.length > 0 ? Math.round((paid / recs.length) * 100) : 0
      };
    });
  }, [records]);

  // Extraction of reasons/notes for narrative
  const unpaidReasonings = useMemo(() => {
    return records
      .filter(r => (r.statusBayar === 'BELUM BAYAR' || r.statusBayar === 'DIBATALKAN') && r.note)
      .map(r => ({
        nopol: r.nopol,
        nama: r.nama,
        tglEntri: r.tgl,
        jatemFakt: r.jatemFakt,
        transaksi: r.transaksi,
        note: r.note
      }));
  }, [records]);

  return (
    <div className="space-y-8 pb-12">
      
      {/* Hero Visual Section: Clean 3D presentation */}
      <div className="relative rounded-2xl overflow-hidden border border-slate-800 bg-slate-900 shadow-xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
          
          {/* Left Text Zone */}
          <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-between space-y-6">
            <div className="space-y-3">
              <div className="flex items-center gap-3 pb-1">
                <img
                  src="/logo_jabar_transparan.png"
                  alt="Lambang Jawa Barat"
                  className="w-8 h-10 object-contain drop-shadow shrink-0"
                />
                <div className="flex flex-col">
                  <span className="text-[10px] sm:text-[11px] font-semibold text-slate-400 tracking-wider uppercase whitespace-nowrap">
                    Pemerintah Daerah Provinsi Jawa Barat · Badan Pendapatan Daerah
                  </span>
                  <span className="text-xs sm:text-sm font-extrabold text-amber-300 tracking-wide uppercase whitespace-nowrap">
                    Pusat Pengelolaan Pendapatan Daerah Wilayah Kota Cirebon
                  </span>
                </div>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight leading-tight">
                SISTEM PENGAWASAN PENETAPAN &amp; PENGARSIPAN KBM
              </h1>
              <p className="text-sm text-slate-300 leading-relaxed max-w-xl">
                Sistem Pengawasan Penetapan dan pengarsipan KBM baru pada P3DW Kota Cirebon, kontrol jatuh tempo 30 hari kalender dan monitoring pembayaran PKB/BBNKB I
              </p>
            </div>

            {/* Quick CTAs and Highlights */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={onOpenNewModal}
                className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 active:scale-95 text-slate-950 font-bold text-xs rounded-lg shadow-md transition-all flex items-center gap-2 cursor-pointer"
              >
                <span>+ Entri Faktur Baru</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={onNavigateToUnpaid}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 active:scale-95 text-amber-300 font-semibold text-xs rounded-lg border border-slate-700 transition-all flex items-center gap-2 cursor-pointer"
              >
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <span>Lihat {unpaidCount} KBM Belum Bayar</span>
              </button>
            </div>

            {/* Bottom mini status strip */}
            <div className="flex items-center gap-6 pt-2 border-t border-slate-800 text-xs text-slate-400 font-mono">
              <div>
                Hari Ini: <span className="font-bold text-white tabular-nums">{todayRegistered} Entri</span>
              </div>
              <span aria-hidden="true">/</span>
              <div>
                Bayar Hari Ini: <span className="font-bold text-emerald-400 tabular-nums">{todayPaid} Unit</span>
              </div>
              <span aria-hidden="true">/</span>
              <div>
                Kepatuhan Total: <span className="font-bold text-amber-400 tabular-nums">{paidPercentage}%</span>
              </div>
            </div>
          </div>

          {/* Right Visual Image Zone */}
          <div className="lg:col-span-5 relative min-h-[220px] lg:min-h-full bg-slate-950">
            <img
              src={heroImage}
              alt="Visualisasi Digital Arsip KBM Baru Cirebon"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-transparent to-transparent lg:bg-gradient-to-r lg:from-slate-900 lg:via-transparent lg:to-transparent" />
            <div className="absolute bottom-3 right-3 bg-slate-950/85 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-800 text-[11px] text-amber-300 font-mono flex items-center gap-2 shadow">
              <img src="/logo_jabar_transparan.png" alt="Logo Jawa Barat" className="w-3.5 h-4.5 object-contain" />
              <span>Samsat Kota Cirebon · Bapenda Jabar</span>
            </div>
          </div>

        </div>
      </div>

      {/* 4 Top KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: Total Pendaftaran */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium uppercase tracking-wider">Total Pendaftaran KBM</span>
            <Car className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-3xl font-extrabold text-white font-mono tabular-nums">
            {totalCount}
            <span className="text-xs font-normal text-slate-400 ml-1.5 font-sans">Berkas</span>
          </div>
          <div className="text-xs text-slate-400 flex items-center justify-between pt-1 border-t border-slate-800">
            <span>Entri Hari Ini</span>
            <span className="font-bold text-amber-400 font-mono tabular-nums">+{todayRegistered} unit</span>
          </div>
        </div>

        {/* Card 2: Sudah Bayar */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium uppercase tracking-wider">Realisasi Membayar</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-3xl font-extrabold text-emerald-400 font-mono tabular-nums">
            {paidCount}
            <span className="text-xs font-normal text-slate-400 ml-1.5 font-sans">Unit ({paidPercentage}%)</span>
          </div>
          <div className="text-xs text-slate-400 flex items-center justify-between pt-1 border-t border-slate-800">
            <span>Pelunasan Hari Ini</span>
            <span className="font-bold text-emerald-300 font-mono tabular-nums">{todayPaid} unit</span>
          </div>
        </div>

        {/* Card 3: Belum Membayar */}
        <div 
          onClick={onNavigateToUnpaid}
          className="bg-slate-900 border border-amber-500/30 hover:border-amber-400/60 rounded-xl p-5 shadow-sm space-y-2 cursor-pointer transition-colors group"
        >
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium uppercase tracking-wider text-amber-400">Belum / Tunda Bayar</span>
            <XCircle className="w-4 h-4 text-red-400" />
          </div>
          <div className="text-3xl font-extrabold text-red-400 font-mono tabular-nums">
            {unpaidCount}
            <span className="text-xs font-normal text-slate-400 ml-1.5 font-sans">Unit ({unpaidPercentage}%)</span>
          </div>
          <div className="text-xs text-amber-400/90 flex items-center justify-between pt-1 border-t border-slate-800 group-hover:text-amber-300">
            <span>Perlu Pengendalian</span>
            <span className="font-bold flex items-center gap-1 font-mono">
              Buka Ceklis <ArrowRight className="w-3 h-3" />
            </span>
          </div>
        </div>

        {/* Card 4: Rasio Kepatuhan Pajak */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium uppercase tracking-wider">Rasio Kepatuhan</span>
            <TrendingUp className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-3xl font-extrabold text-amber-400 font-mono tabular-nums">
            {paidPercentage}%
          </div>
          <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
            <div 
              className="bg-emerald-500 h-2 rounded-full transition-all duration-500"
              style={{ width: `${paidPercentage}%` }}
            />
          </div>
        </div>

      </div>

      {/* Section: COUNTING TRANSAKSI BERDASARKAN TGL ENTRI */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
              <Calendar className="w-4 h-4 text-amber-400" />
              Counting Transaksi Berdasarkan TGL Entri
            </h2>
            <p className="text-xs text-slate-400">
              Rekapitulasi volume pendaftaran harian berkas KBM baru P3DW Samsat Kota Cirebon
            </p>
          </div>

          {/* Quick Segmented Date Filter */}
          <div className="flex items-center gap-1 p-1 bg-slate-950 border border-slate-800 rounded-lg shrink-0">
            <button
              onClick={() => setSelectedEntryDateFilter('all')}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                selectedEntryDateFilter === 'all'
                  ? 'bg-blue-600 text-white font-semibold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Semua Tanggal ({records.length})
            </button>
            <button
              onClick={() => setSelectedEntryDateFilter('today')}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                selectedEntryDateFilter === 'today'
                  ? 'bg-amber-400 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Hari Ini ({todayRegistered})
            </button>
            <button
              onClick={() => setSelectedEntryDateFilter('last7')}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                selectedEntryDateFilter === 'last7'
                  ? 'bg-blue-600 text-white font-semibold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              7 Hari Terakhir
            </button>
          </div>
        </div>

        {/* Visual Daily Volume Bars */}
        <div className="space-y-3">
          <div className="text-xs font-medium text-slate-400">Distribusi Pendaftaran per Tanggal:</div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
            {countingByDate.slice(0, 6).map((item) => {
              const maxVal = Math.max(...countingByDate.map(d => d.total), 1);
              const heightPercent = Math.max((item.total / maxVal) * 100, 20);
              const isToday = item.date === todayStr;

              return (
                <div
                  key={item.date}
                  className={`p-3 rounded-lg border text-center transition-all ${
                    isToday
                      ? 'bg-blue-950/40 border-amber-400/50 shadow-sm'
                      : 'bg-slate-950/60 border-slate-800'
                  }`}
                >
                  <div className="text-[11px] font-mono text-slate-400">
                    {formatIndoDate(item.date).split(' ')[0]} {formatIndoDate(item.date).split(' ')[1]}
                  </div>
                  <div className="text-xl font-bold font-mono text-white my-1 tabular-nums">
                    {item.total}
                    <span className="text-[10px] text-slate-500 font-sans ml-1">KBM</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden my-1">
                    <div
                      className="bg-amber-400 h-1.5 rounded-full"
                      style={{ width: `${item.rate}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[10px] font-mono text-slate-400">
                    <span className="text-emerald-400">{item.paid} B</span>
                    <span className="text-red-400">{item.unpaid} TB</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Detailed Table for Entry Date Counting */}
        <div className="overflow-x-auto rounded-lg border border-slate-800">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase font-semibold font-mono text-[11px] border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-4">TGL Entri</th>
                <th className="py-2.5 px-4 text-center">Jumlah KBM Didaftarkan</th>
                <th className="py-2.5 px-4 text-center">Sudah Membayar</th>
                <th className="py-2.5 px-4 text-center">Belum Membayar</th>
                <th className="py-2.5 px-4 text-right">Persentase Realisasi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 bg-slate-900/40">
              {countingByDate.slice(0, 8).map((row) => (
                <tr key={row.date} className="hover:bg-slate-850/50 transition-colors">
                  <td className="py-2.5 px-4 font-mono font-medium text-white flex items-center gap-2">
                    <Calendar className="w-3.5 h-3.5 text-blue-400" />
                    <span>{formatIndoDate(row.date)}</span>
                    {row.date === todayStr && (
                      <span className="text-[10px] px-1.5 py-0.2 bg-amber-400/20 text-amber-300 rounded font-sans font-bold">
                        Hari Ini
                      </span>
                    )}
                  </td>
                  <td className="py-2.5 px-4 text-center font-mono font-bold text-white tabular-nums">
                    {row.total} Berkas
                  </td>
                  <td className="py-2.5 px-4 text-center font-mono text-emerald-400 font-semibold tabular-nums">
                    {row.paid} Unit
                  </td>
                  <td className="py-2.5 px-4 text-center font-mono text-red-400 font-semibold tabular-nums">
                    {row.unpaid} Unit
                  </td>
                  <td className="py-2.5 px-4 text-right font-mono font-bold text-amber-400 tabular-nums">
                    {row.rate}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Section: TABEL PERBANDINGAN JUMLAH YANG MEMBAYAR DAN TIDAK MEMBAYAR */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Comparison 1: Per Golongan Roda */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-white">Perbandingan Berdasarkan RODA</h3>
              <p className="text-[11px] text-slate-400">R2 (Motor), R3 (Tiga Roda), R4 (Mobil)</p>
            </div>
            <Car className="w-4 h-4 text-blue-400" />
          </div>

          <div className="space-y-3.5">
            {comparisonByRoda.map((item) => {
              const rate = item.total > 0 ? Math.round((item.paid / item.total) * 100) : 0;
              return (
                <div key={item.key} className="space-y-1.5 bg-slate-950/50 p-3 rounded-lg border border-slate-800">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-semibold text-white">{item.label}</span>
                    <span className="font-mono text-amber-400 font-bold tabular-nums">
                      {item.paid} / {item.total} Lunas ({rate}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-2 flex overflow-hidden">
                    <div className="bg-emerald-500 h-2" style={{ width: `${rate}%` }} />
                    <div className="bg-red-500 h-2" style={{ width: `${100 - rate}%` }} />
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                    <span className="text-emerald-400">Bayar: {item.paid}</span>
                    <span className="text-red-400">Belum: {item.unpaid}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Comparison 2: Per Jenis Transaksi */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-white">Perbandingan TRANSAKSI</h3>
              <p className="text-[11px] text-slate-400">CKD, CBU, GIIAS, EX DUMP, LISTRIK/HYB</p>
            </div>
            <Layers className="w-4 h-4 text-amber-400" />
          </div>

          <div className="space-y-2.5">
            {comparisonByTransaksi.map((item) => (
              <div key={item.transaksi} className="flex items-center justify-between text-xs p-2 rounded bg-slate-950/40 border border-slate-800/80">
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-blue-300 w-24 truncate">{item.transaksi}</span>
                  <span className="text-slate-400 text-[11px]">({item.total} berkas)</span>
                </div>
                <div className="flex items-center gap-3 font-mono text-xs">
                  <span className="text-emerald-400 font-semibold">{item.paid} Bayar</span>
                  <span className="text-red-400 font-semibold">{item.unpaid} Belum</span>
                  <span className="text-amber-400 font-bold w-10 text-right">{item.rate}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Comparison 3: Per Kode Plat */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-white">Perbandingan Jenis PLAT</h3>
              <p className="text-[11px] text-slate-400">Plat 1 (Pribadi), Plat 2 (Umum), Plat 3 (Dinas)</p>
            </div>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>

          <div className="space-y-3">
            {comparisonByPlat.map((item) => (
              <div key={item.plat} className="p-3 bg-slate-950/50 rounded-lg border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-white">{item.label}</span>
                  <span className="font-mono text-amber-400 font-bold">{item.rate}% Lunas</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-mono">
                  <div className="flex-1 bg-emerald-950/60 border border-emerald-800/60 text-emerald-300 px-2 py-1 rounded text-center">
                    Bayar: {item.paid}
                  </div>
                  <div className="flex-1 bg-red-950/60 border border-red-800/60 text-red-300 px-2 py-1 rounded text-center">
                    Belum: {item.unpaid}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Section: NARASI ANALITIK OPERASIONAL & LOG REASONING CATATAN USER */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded bg-amber-400/20 text-amber-400 flex items-center justify-center font-bold text-sm">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                Narasi Analisis Operasional &amp; Catatan Reasoning Petugas
              </h2>
              <p className="text-xs text-slate-400">
                Laporan komprehensif pendaftaran, realisasi pembayaran, dan kendala penundaan
              </p>
            </div>
          </div>
          <button
            onClick={onNavigateToArchive}
            className="text-xs font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-1"
          >
            Buka Tabel Lengkap <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Narrative Box */}
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs leading-relaxed text-slate-300 space-y-2.5">
          <p>
            Berdasarkan basis data pengarsipan <strong>KBM BARU P3DW KOTA CIREBON</strong>, 
            dari total akumulasi <strong className="text-white font-mono">{totalCount} berkas</strong> kendaraan bermotor baru yang terdaftar, 
            sebanyak <strong className="text-emerald-400 font-mono">{paidCount} unit ({paidPercentage}%)</strong> telah menyelesaikan pelunasan bea balik nama kendaraan bermotor (BBNKB) dan pajak kendaraan bermotor (PKB). 
            Pada tanggal hari ini ({formatIndoDate(todayStr)}), tercatat pendaftaran baru sebanyak <strong className="text-amber-400 font-mono">{todayRegistered} unit</strong>, dengan realisasi pelunasan kasir sebanyak <strong className="text-emerald-400 font-mono">{todayPaid} unit</strong>.
          </p>
          <p>
            Sementara itu, sebanyak <strong className="text-red-400 font-mono">{unpaidCount} unit ({unpaidPercentage}%)</strong> saat ini berstatus <em>BELUM BAYAR / TERTUNDA</em>. 
            Petugas pengarsipan dapat melakukan pemindahan status dengan mengubah tanggal bayar menjadi hari ini begitu wajib pajak atau dealer menyerahkan bukti transaksi di loket kasir.
          </p>
        </div>

        {/* User Reasonings Summary from Note Field */}
        <div className="space-y-2 pt-2">
          <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
            <span>Daftar Reasoning / Catatan Alasan Tertunda dari Petugas:</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {unpaidReasonings.length === 0 ? (
              <div className="p-4 bg-slate-950/40 rounded-lg text-center text-xs text-slate-500">
                Tidak ada kendaraan berstatus belum bayar yang memiliki catatan khusus.
              </div>
            ) : (
              unpaidReasonings.map((item, idx) => (
                <div key={idx} className="p-3 bg-slate-950/70 border border-slate-800 rounded-lg space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-mono font-bold text-amber-300">{item.nopol}</span>
                    <span className="text-[10px] text-slate-400 font-mono">Faktur Jatem: {item.jatemFakt}</span>
                  </div>
                  <div className="text-[11px] text-slate-300 font-medium truncate">
                    {item.nama} · <span className="text-slate-400">{item.transaksi}</span>
                  </div>
                  <div className="text-xs text-slate-300 bg-slate-900/90 p-2 rounded border border-slate-800/80 italic">
                    "{item.note}"
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

      </div>

    </div>
  );
};
