import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  Download, 
  FileSpreadsheet, 
  FileText, 
  Edit3, 
  Trash2, 
  Folder, 
  Eye, 
  Check, 
  X, 
  Calendar, 
  Copy,
  ExternalLink,
  ChevronDown,
  RotateCcw,
  CheckCircle2,
  Clock,
  Printer,
  Image as ImageIcon,
  Grid,
  AlertTriangle
} from 'lucide-react';
import { KbmRecord, RodaType, TransaksiType, PlatType, StatusBayar } from '../types/archive';
import { 
  formatIndoDate, 
  exportToCSV, 
  exportToExcel, 
  getPlatLabel, 
  getRodaLabel, 
  getTodayDateString, 
  calculateJatuhTempo,
  getEvidentImageUrl,
  isOverdue
} from '../utils/formatters';

interface ArchiveTableViewProps {
  records: KbmRecord[];
  onEditRecord: (record: KbmRecord) => void;
  onUpdateRecord: (updated: KbmRecord) => void;
  onDeleteRecord: (id: string) => void;
  onOpenEvident: (evidentUrl: string, title: string) => void;
  onPrintPreview: () => void;
}

export const ArchiveTableView: React.FC<ArchiveTableViewProps> = ({
  records,
  onEditRecord,
  onUpdateRecord,
  onDeleteRecord,
  onOpenEvident,
  onPrintPreview,
}) => {
  const todayStr = getTodayDateString();

  // Filter states (TGL, TGL FAKTUR, TGL BAYAR, NOPOL, NAMA, PLAT, RODA, TRANSAKSI, EVIDENT)
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterTglEntri, setFilterTglEntri] = useState<string>('');
  const [filterTglFaktur, setFilterTglFaktur] = useState<string>('');
  const [filterTglBayar, setFilterTglBayar] = useState<string>('');
  const [filterRoda, setFilterRoda] = useState<string>('ALL');
  const [filterTransaksi, setFilterTransaksi] = useState<string>('ALL');
  const [filterPlat, setFilterPlat] = useState<string>('ALL');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [filterEvident, setFilterEvident] = useState<'ALL' | 'WITH_EVIDENT' | 'WITHOUT_EVIDENT'>('ALL');
  const [isFilterExpanded, setIsFilterExpanded] = useState<boolean>(false);

  // View Mode: 'table' vs 'images' (Tampilan Image Pengecekan Petugas Penetapan)
  const [viewMode, setViewMode] = useState<'table' | 'images'>('table');
  const [showImageThumbnails, setShowImageThumbnails] = useState<boolean>(true);

  // Inline editing row state
  const [inlineEditingId, setInlineEditingId] = useState<string | null>(null);
  const [inlineData, setInlineData] = useState<Partial<KbmRecord>>({});

  // Filter records
  const filteredRecords = useMemo(() => {
    return records.filter(r => {
      // Free text search (Nopol, Nama, Note, Link)
      if (searchQuery) {
        const q = searchQuery.toLowerCase().trim();
        const match = r.nopol.toLowerCase().includes(q) ||
                      r.nama.toLowerCase().includes(q) ||
                      r.note.toLowerCase().includes(q) ||
                      r.linkFile.toLowerCase().includes(q);
        if (!match) return false;
      }
      // Tgl Entri filter
      if (filterTglEntri && r.tgl !== filterTglEntri) return false;
      // Tgl Faktur filter
      if (filterTglFaktur && r.tglFaktur !== filterTglFaktur) return false;
      // Tgl Bayar filter
      if (filterTglBayar && r.tglBayar !== filterTglBayar) return false;
      // Enums
      if (filterRoda !== 'ALL' && r.roda !== filterRoda) return false;
      if (filterTransaksi !== 'ALL' && r.transaksi !== filterTransaksi) return false;
      if (filterPlat !== 'ALL' && r.plat !== filterPlat) return false;
      if (filterStatus !== 'ALL' && r.statusBayar !== filterStatus) return false;

      // Filter Foto Evident (Untuk Pengecekan Petugas Penetapan)
      if (filterEvident === 'WITH_EVIDENT' && (!r.evident && !r.evidentName)) return false;
      if (filterEvident === 'WITHOUT_EVIDENT' && (r.evident || r.evidentName)) return false;

      return true;
    });
  }, [
    records,
    searchQuery,
    filterTglEntri,
    filterTglFaktur,
    filterTglBayar,
    filterRoda,
    filterTransaksi,
    filterPlat,
    filterStatus,
    filterEvident
  ]);

  // Reset filters
  const handleResetFilters = () => {
    setSearchQuery('');
    setFilterTglEntri('');
    setFilterTglFaktur('');
    setFilterTglBayar('');
    setFilterRoda('ALL');
    setFilterTransaksi('ALL');
    setFilterPlat('ALL');
    setFilterStatus('ALL');
    setFilterEvident('ALL');
  };

  // Start inline editing
  const startInlineEdit = (record: KbmRecord) => {
    setInlineEditingId(record.id);
    setInlineData({ ...record });
  };

  const cancelInlineEdit = () => {
    setInlineEditingId(null);
    setInlineData({});
  };

  const saveInlineEdit = (originalRecord: KbmRecord) => {
    const newStatus = (inlineData.statusBayar || originalRecord.statusBayar) as StatusBayar;
    let finalTglBayar = inlineData.tglBayar !== undefined ? inlineData.tglBayar : originalRecord.tglBayar;
    let finalJatemFakt = inlineData.jatemFakt !== undefined ? inlineData.jatemFakt : originalRecord.jatemFakt;

    if (newStatus === 'SUDAH BAYAR') {
      if (!finalTglBayar) finalTglBayar = todayStr;
      if (!finalJatemFakt) finalJatemFakt = calculateJatuhTempo(todayStr, originalRecord.rumusHari || 30);
    } else if (newStatus === 'DIBATALKAN') {
      finalTglBayar = '';
    }

    const updated: KbmRecord = {
      ...originalRecord,
      ...inlineData,
      statusBayar: newStatus,
      tglBayar: finalTglBayar,
      jatemFakt: finalJatemFakt.trim(),
      nopol: (inlineData.nopol || originalRecord.nopol).toUpperCase().trim(),
      nama: (inlineData.nama || originalRecord.nama).toUpperCase().trim(),
      updatedAt: new Date().toISOString(),
    };
    onUpdateRecord(updated);
    setInlineEditingId(null);
    setInlineData({});
  };

  // Copy local folder path to clipboard
  const handleCopyPath = (path: string) => {
    if (!path) return;
    navigator.clipboard.writeText(path);
    alert(`Alamat folder PC telah disalin ke clipboard:\n${path}`);
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* Top Controls Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
              <span>Semua Arsip Berkas KBM Baru</span>
              <span className="text-xs px-2 py-0.5 rounded bg-blue-600/30 border border-blue-500/40 text-blue-300 font-mono">
                {filteredRecords.length} Data Tersaring
              </span>
            </h1>
            <p className="text-xs text-slate-400">
              Pusat data faktur, plat nomor, tanggal bayar, link folder komputer &amp; foto evident
            </p>
          </div>

          {/* Export Action Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => exportToCSV(filteredRecords, 'ARSIP_KBM_CIREBON')}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700 transition-colors flex items-center gap-1.5"
              title="Unduh hasil filter sebagai CSV"
            >
              <Download className="w-3.5 h-3.5 text-blue-400" />
              <span>CSV</span>
            </button>

            <button
              onClick={() => exportToExcel(filteredRecords, 'REKAP_EXCEL_KBM_CIREBON')}
              className="px-3 py-2 bg-emerald-800/80 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors flex items-center gap-1.5"
              title="Unduh hasil filter sebagai format Excel"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-300" />
              <span>Excel (.xls)</span>
            </button>

            <button
              onClick={onPrintPreview}
              className="px-3 py-2 bg-blue-700 hover:bg-blue-600 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors flex items-center gap-1.5"
              title="Cetak format surat resmi Samsat"
            >
              <Printer className="w-3.5 h-3.5 text-amber-300" />
              <span>Cetak / PDF</span>
            </button>
          </div>
        </div>

        {/* Primary Search Bar, View Mode Switcher, and Expand Toggle */}
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center gap-3">
          {/* Search Box */}
          <div className="relative flex-1 w-full">
            <input
              type="text"
              placeholder="Cari NOPOL (contoh: E 2841 BQ), Nama Pemilik, atau Catatan..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-9 pr-4 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-400 font-mono font-medium"
            />
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
          </div>

          {/* Mode Tampilan Switcher (Tabel vs Tampilan Image Pengecekan Petugas Penetapan) */}
          <div className="flex items-center gap-1 p-1 bg-slate-950 border border-slate-800 rounded-lg shrink-0">
            <button
              type="button"
              onClick={() => setViewMode('table')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-semibold transition-all cursor-pointer ${
                viewMode === 'table'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
              title="Tampilkan daftar dalam bentuk tabel data rinci"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Tabel Data</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('images')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-semibold transition-all cursor-pointer ${
                viewMode === 'images'
                  ? 'bg-amber-400 text-slate-950 font-bold shadow-sm'
                  : 'text-amber-400/80 hover:text-amber-300'
              }`}
              title="Buka mode tampilan image untuk mempermudah pengecekan evident faktur oleh Petugas Penetapan"
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span>Tampilan Image (Pengecekan Petugas)</span>
            </button>
          </div>

          {/* Toggle Filter Kriteria */}
          <button
            onClick={() => setIsFilterExpanded(!isFilterExpanded)}
            className={`px-3.5 py-2.5 rounded-lg text-xs font-semibold border flex items-center justify-center gap-2 transition-colors shrink-0 cursor-pointer ${
              isFilterExpanded || filterTglEntri || filterTglFaktur || filterTglBayar || filterRoda !== 'ALL' || filterTransaksi !== 'ALL' || filterPlat !== 'ALL' || filterStatus !== 'ALL' || filterEvident !== 'ALL'
                ? 'bg-amber-400/20 border-amber-400 text-amber-300'
                : 'bg-slate-950 border-slate-700 text-slate-300 hover:text-white'
            }`}
          >
            <Filter className="w-3.5 h-3.5" />
            <span>Filter Kriteria</span>
            <ChevronDown className={`w-3.5 h-3.5 transition-transform ${isFilterExpanded ? 'rotate-180' : ''}`} />
          </button>

          {(searchQuery || filterTglEntri || filterTglFaktur || filterTglBayar || filterRoda !== 'ALL' || filterTransaksi !== 'ALL' || filterPlat !== 'ALL' || filterStatus !== 'ALL' || filterEvident !== 'ALL') && (
            <button
              onClick={handleResetFilters}
              className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-lg text-xs shrink-0 cursor-pointer"
              title="Reset Semua Filter"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Expanded Filters Drawer: TGL, TGL FAKTUR, TGL BAYAR, RODA, TRANSAKSI, PLAT, STATUS, EVIDENT */}
        {isFilterExpanded && (
          <div className="pt-3 border-t border-slate-800 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3 text-xs">
            
            {/* TGL Entri */}
            <div>
              <label className="block text-slate-400 mb-1">TGL Entri:</label>
              <input
                type="date"
                value={filterTglEntri}
                onChange={(e) => setFilterTglEntri(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-xs text-white font-mono"
              />
            </div>

            {/* TGL Faktur */}
            <div>
              <label className="block text-slate-400 mb-1">TGL Faktur:</label>
              <input
                type="date"
                value={filterTglFaktur}
                onChange={(e) => setFilterTglFaktur(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-xs text-white font-mono"
              />
            </div>

            {/* TGL Bayar */}
            <div>
              <label className="block text-slate-400 mb-1">TGL Bayar:</label>
              <input
                type="date"
                value={filterTglBayar}
                onChange={(e) => setFilterTglBayar(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-xs text-white font-mono"
              />
            </div>

            {/* RODA */}
            <div>
              <label className="block text-slate-400 mb-1">RODA:</label>
              <select
                value={filterRoda}
                onChange={(e) => setFilterRoda(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-xs text-white"
              >
                <option value="ALL">Semua Roda</option>
                <option value="R2">R2 (Sepeda Motor)</option>
                <option value="R3">R3 (Tiga Roda)</option>
                <option value="R4">R4 (Roda 4+ / Mobil)</option>
              </select>
            </div>

            {/* TRANSAKSI */}
            <div>
              <label className="block text-slate-400 mb-1">TRANSAKSI:</label>
              <select
                value={filterTransaksi}
                onChange={(e) => setFilterTransaksi(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-xs text-white"
              >
                <option value="ALL">Semua Transaksi</option>
                <option value="CKD">CKD</option>
                <option value="CBU">CBU</option>
                <option value="GIIAS">GIIAS</option>
                <option value="EX DUMP">EX DUMP</option>
                <option value="LISTRIK/HYB">LISTRIK/HYB</option>
              </select>
            </div>

            {/* PLAT */}
            <div>
              <label className="block text-slate-400 mb-1">PLAT:</label>
              <select
                value={filterPlat}
                onChange={(e) => setFilterPlat(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-xs text-white"
              >
                <option value="ALL">Semua Plat</option>
                <option value="1">Plat 1 (Pribadi)</option>
                <option value="2">Plat 2 (Kuning)</option>
                <option value="3">Plat 3 (Merah)</option>
              </select>
            </div>

            {/* STATUS BAYAR */}
            <div>
              <label className="block text-slate-400 mb-1">Status Bayar:</label>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-xs text-white"
              >
                <option value="ALL">Semua Status</option>
                <option value="SUDAH BAYAR">Sudah Bayar</option>
                <option value="BELUM BAYAR">Belum Bayar</option>
                <option value="DIBATALKAN">Dibatalkan (Batal Bayar)</option>
              </select>
            </div>

            {/* FILTER EVIDENT IMAGE (PENGECEKAN PETUGAS PENETAPAN) */}
            <div>
              <label className="block text-amber-300 font-semibold mb-1 flex items-center gap-1">
                <ImageIcon className="w-3 h-3 text-amber-400" />
                <span>Foto Evident:</span>
              </label>
              <select
                value={filterEvident}
                onChange={(e) => setFilterEvident(e.target.value as 'ALL' | 'WITH_EVIDENT' | 'WITHOUT_EVIDENT')}
                className="w-full bg-slate-950 border border-amber-400/50 rounded px-2 py-1.5 text-xs text-amber-300 font-medium focus:outline-none focus:border-amber-400"
              >
                <option value="ALL">Semua Berkas</option>
                <option value="WITH_EVIDENT">Hanya Ada Foto Evident</option>
                <option value="WITHOUT_EVIDENT">Tanpa Foto Evident</option>
              </select>
            </div>

          </div>
        )}
      </div>

      {/* Sub-header Controls Strip */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-1 text-xs">
        <div className="flex items-center gap-2.5">
          <span className="font-bold text-white flex items-center gap-1.5">
            {viewMode === 'images' ? (
              <>
                <ImageIcon className="w-4 h-4 text-amber-400" />
                <span>Mode Pengecekan Foto Evident &amp; Berkas (Petugas Penetapan)</span>
              </>
            ) : (
              <>
                <FileText className="w-4 h-4 text-blue-400" />
                <span>Mode Tabel Data Rinci KBM Baru</span>
              </>
            )}
          </span>
          <span className="text-slate-500" aria-hidden="true">·</span>
          <span className="text-slate-400 font-mono">
            {filteredRecords.length} berkas ditampilkan
          </span>
        </div>

        {viewMode === 'table' ? (
          <label className="flex items-center gap-2 cursor-pointer select-none text-slate-300 hover:text-white bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg shadow-sm">
            <input
              type="checkbox"
              checked={showImageThumbnails}
              onChange={(e) => setShowImageThumbnails(e.target.checked)}
              className="rounded bg-slate-950 border-slate-700 text-amber-400 focus:ring-0"
            />
            <ImageIcon className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-[11px] font-medium">Tampilkan Thumbnail Foto di Kolom Tabel</span>
          </label>
        ) : (
          <div className="text-[11px] text-amber-300 font-medium flex items-center gap-1 bg-amber-400/10 px-3 py-1.5 rounded-lg border border-amber-400/20">
            <span>Tip: Klik foto dokumen untuk memperbesar (zoom) atau periksa fisik berkas</span>
          </div>
        )}
      </div>

      {/* VIEW MODE 1: TAMPILAN IMAGE (PENGECEKAN PETUGAS PENETAPAN) */}
      {viewMode === 'images' ? (
        <div className="space-y-4">
          {filteredRecords.length === 0 ? (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-12 text-center text-slate-500 space-y-3">
              <ImageIcon className="w-10 h-10 text-slate-600 mx-auto" />
              <p className="font-semibold text-slate-400">Tidak ada berkas yang sesuai dengan filter.</p>
              <p className="text-xs">Coba ubah kata kunci pencarian atau reset filter kriteria.</p>
              <button
                onClick={handleResetFilters}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg inline-flex items-center gap-1 mt-2"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Filter</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredRecords.map((r) => {
                const isPaid = r.statusBayar === 'SUDAH BAYAR';
                const dueInfo = isOverdue(r.jatemFakt, r.statusBayar);
                const evidentUrl = getEvidentImageUrl(r);

                return (
                  <div
                    key={r.id}
                    className="bg-slate-900 border border-slate-800 hover:border-amber-400/60 rounded-xl overflow-hidden shadow-sm hover:shadow-lg transition-all flex flex-col group"
                  >
                    {/* Card Header: Nopol & Badges */}
                    <div className="p-3 bg-slate-850 border-b border-slate-800 flex items-center justify-between gap-2">
                      <div className="flex flex-col">
                        <span className="font-mono font-bold text-amber-300 text-sm tracking-wider">
                          {r.nopol}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          Tgl Entri: {r.tgl}
                        </span>
                      </div>
                      
                      <div className="flex items-center gap-1 font-mono text-[10px]">
                        <span className="px-1.5 py-0.5 rounded bg-blue-900/60 border border-blue-700/60 text-blue-200 font-bold">
                          {r.roda}
                        </span>
                        <span className="px-1.5 py-0.5 rounded bg-amber-900/50 border border-amber-700/60 text-amber-300 font-bold">
                          P{r.plat}
                        </span>
                      </div>
                    </div>

                    {/* Image Viewport / Preview */}
                    <div className="relative aspect-[16/10] bg-black overflow-hidden border-b border-slate-800 group/img">
                      <img
                        src={evidentUrl}
                        alt={`Evident ${r.nopol}`}
                        className="w-full h-full object-contain p-1 group-hover/img:scale-105 transition-transform duration-200"
                        loading="lazy"
                      />

                      {/* Click overlay for Zoom */}
                      <button
                        type="button"
                        onClick={() => onOpenEvident(evidentUrl, `Dokumen Evident: ${r.nopol} - ${r.nama}`)}
                        className="absolute inset-0 bg-slate-950/60 opacity-0 group-hover/img:opacity-100 transition-opacity flex flex-col items-center justify-center gap-1 text-white cursor-pointer"
                        title="Klik untuk zoom & periksa foto dokumen"
                      >
                        <Eye className="w-6 h-6 text-amber-400 drop-shadow" />
                        <span className="text-xs font-semibold drop-shadow">Periksa Dokumen Lengkap</span>
                      </button>

                      {/* Status Overlay Badge */}
                      <div className="absolute top-2 right-2 pointer-events-none">
                        {isPaid ? (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950/90 text-emerald-300 border border-emerald-700 shadow font-mono">
                            LUNAS
                          </span>
                        ) : r.statusBayar === 'DIBATALKAN' ? (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-950/90 text-red-300 border border-red-700 shadow font-mono">
                            BATAL BAYAR
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950/90 text-amber-300 border border-amber-700 shadow font-mono">
                            BELUM BAYAR
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Card Body: Details for Petugas Penetapan */}
                    <div className="p-3.5 space-y-2.5 flex-1 flex flex-col justify-between text-xs">
                      <div className="space-y-2">
                        {/* Wajib Pajak */}
                        <div>
                          <div className="text-[10px] font-medium text-slate-400 uppercase tracking-wider">
                            Wajib Pajak / Pemilik
                          </div>
                          <div className="font-semibold text-white truncate" title={r.nama}>
                            {r.nama}
                          </div>
                        </div>

                        {/* Faktur & Jatem */}
                        <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-800/80 font-mono text-[11px]">
                          <div>
                            <span className="text-slate-400 text-[10px] block">Tgl Faktur:</span>
                            <span className="text-slate-300 font-medium">{r.tglFaktur}</span>
                          </div>
                          <div>
                            <span className="text-slate-400 text-[10px] block">Jatem (+{r.rumusHari || 30}H):</span>
                            {r.jatemFakt ? (
                              <span className="text-amber-300 font-bold">{r.jatemFakt}</span>
                            ) : (
                              <span className="text-red-400 font-bold italic text-[10px]">Dihapus (Batal)</span>
                            )}
                          </div>
                        </div>

                        {/* Overdue Warning */}
                        {dueInfo.isOverdue && !isPaid && (
                          <div className="text-[10px] font-semibold text-red-400 bg-red-950/40 border border-red-900/60 px-2 py-1 rounded flex items-center gap-1 font-mono">
                            <AlertTriangle className="w-3 h-3 shrink-0" />
                            <span>Terlambat {Math.abs(dueInfo.daysRemaining)} hari dari jatuh tempo</span>
                          </div>
                        )}

                        {/* Reasoning / Note */}
                        <div className="bg-slate-950/70 border border-slate-800 rounded p-2 text-[11px] space-y-0.5">
                          <span className="text-[10px] text-amber-400/90 font-medium uppercase tracking-wider block">
                            Catatan Reasoning:
                          </span>
                          <p className="text-slate-300 italic line-clamp-2">
                            {r.note || 'Belum ada catatan khusus petugas.'}
                          </p>
                        </div>

                        {/* Link File PC */}
                        {r.linkFile && (
                          <button
                            type="button"
                            onClick={() => handleCopyPath(r.linkFile)}
                            className="w-full text-left text-[10px] text-blue-300 hover:text-blue-200 font-mono truncate flex items-center gap-1 underline underline-offset-2 pt-0.5"
                            title={`Salin alamat PC: ${r.linkFile}`}
                          >
                            <Folder className="w-3 h-3 shrink-0 text-amber-400" />
                            <span className="truncate">{r.linkFile}</span>
                          </button>
                        )}
                      </div>

                      {/* Card Footer Actions */}
                      <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-1">
                        <button
                          type="button"
                          onClick={() => onOpenEvident(evidentUrl, `Dokumen Evident: ${r.nopol} - ${r.nama}`)}
                          className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] font-semibold flex items-center gap-1 cursor-pointer"
                        >
                          <Eye className="w-3 h-3 text-amber-300" />
                          <span>Perbesar</span>
                        </button>

                        {!isPaid && (
                          <button
                            type="button"
                            onClick={() => {
                              const refilled = r.jatemFakt || calculateJatuhTempo(todayStr, r.rumusHari || 30);
                              if (window.confirm(`Konfirmasi pembayaran ${r.nopol} dengan Tanggal Bayar hari ini (${todayStr}) dan isi ulang jatuh tempo?`)) {
                                onUpdateRecord({
                                  ...r,
                                  statusBayar: 'SUDAH BAYAR',
                                  tglBayar: todayStr,
                                  jatemFakt: refilled,
                                  note: r.note ? `${r.note} · [Dilunasi Hari Ini ${todayStr}]` : `[Dilunasi Hari Ini ${todayStr}]`,
                                  updatedAt: new Date().toISOString(),
                                });
                              }
                            }}
                            className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[11px] font-bold flex items-center gap-1 cursor-pointer active:scale-95"
                          >
                            <CheckCircle2 className="w-3 h-3" />
                            <span>{r.statusBayar === 'DIBATALKAN' ? 'Bayar & Isi Jatem' : 'Bayar Hari Ini'}</span>
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => onEditRecord(r)}
                          className="p-1.5 text-slate-400 hover:text-white rounded hover:bg-slate-800"
                          title="Ubah Rincian Berkas"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : (
        /* VIEW MODE 2: TABEL DATA RINCI */
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 uppercase font-semibold font-mono text-[11px] border-b border-slate-800">
                <tr>
                  <th className="py-3 px-3 w-10 text-center">No</th>
                  <th className="py-3 px-3">TGL</th>
                  <th className="py-3 px-3">NOPOL</th>
                  <th className="py-3 px-4">NAMA</th>
                  <th className="py-3 px-3">TGL FAKTUR</th>
                  <th className="py-3 px-3">JATEM FAKT</th>
                  <th className="py-3 px-3">TGL BAYAR</th>
                  <th className="py-3 px-2 text-center">RODA</th>
                  <th className="py-3 px-3">TRANSAKSI</th>
                  <th className="py-3 px-2 text-center">PLAT</th>
                  <th className="py-3 px-3">STATUS</th>
                  <th className="py-3 px-3 text-center">EVIDENT</th>
                  <th className="py-3 px-3">LINK FILE PC</th>
                  <th className="py-3 px-4 min-w-[160px]">NOTE</th>
                  <th className="py-3 px-3 text-right">AKSI</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70 bg-slate-900/40">
                {filteredRecords.length === 0 ? (
                  <tr>
                    <td colSpan={15} className="py-12 text-center text-slate-500">
                      Tidak ada arsip kendaraan yang sesuai dengan kriteria filter.
                    </td>
                  </tr>
                ) : (
                  filteredRecords.map((r, index) => {
                    const isInlineEditing = inlineEditingId === r.id;

                    if (isInlineEditing) {
                      // INLINE EDITING ROW: allows user to enter data directly in response table!
                      return (
                        <tr key={r.id} className="bg-amber-950/30 border-y border-amber-500/50">
                          <td className="py-2.5 px-3 text-center font-mono font-bold text-amber-400">
                            {index + 1}
                          </td>

                          {/* TGL */}
                          <td className="py-2.5 px-2">
                            <input
                              type="date"
                              value={inlineData.tgl || r.tgl}
                              onChange={(e) => setInlineData({ ...inlineData, tgl: e.target.value })}
                              onClick={(e) => e.currentTarget.showPicker?.()}
                              className="bg-slate-950 border border-amber-400 rounded px-1.5 py-1 text-xs text-white font-mono w-28 cursor-pointer"
                              title="Klik untuk membuka menu kalender tanggal"
                            />
                          </td>

                          {/* NOPOL */}
                          <td className="py-2.5 px-2">
                            <input
                              type="text"
                              value={inlineData.nopol || r.nopol}
                              onChange={(e) => setInlineData({ ...inlineData, nopol: e.target.value.toUpperCase() })}
                              className="bg-slate-950 border border-amber-400 rounded px-1.5 py-1 text-xs text-amber-300 font-mono font-bold w-24"
                            />
                          </td>

                          {/* NAMA */}
                          <td className="py-2.5 px-2">
                            <input
                              type="text"
                              value={inlineData.nama || r.nama}
                              onChange={(e) => setInlineData({ ...inlineData, nama: e.target.value.toUpperCase() })}
                              className="bg-slate-950 border border-amber-400 rounded px-1.5 py-1 text-xs text-white w-36"
                            />
                          </td>

                          {/* TGL FAKTUR */}
                          <td className="py-2.5 px-2">
                            <input
                              type="date"
                              value={inlineData.tglFaktur || r.tglFaktur}
                              onChange={(e) => {
                                const newFakt = e.target.value;
                                const newJatem = calculateJatuhTempo(newFakt, r.rumusHari || 30);
                                setInlineData({ ...inlineData, tglFaktur: newFakt, jatemFakt: newJatem });
                              }}
                              onClick={(e) => e.currentTarget.showPicker?.()}
                              className="bg-slate-950 border border-slate-700 rounded px-1.5 py-1 text-xs text-white font-mono w-28 cursor-pointer"
                              title="Klik untuk membuka menu kalender tanggal"
                            />
                          </td>

                          {/* JATEM FAKT */}
                          <td className="py-2.5 px-2">
                            <div className="flex items-center gap-1">
                              <input
                                type="date"
                                value={inlineData.jatemFakt !== undefined ? inlineData.jatemFakt : r.jatemFakt}
                                onChange={(e) => setInlineData({ ...inlineData, jatemFakt: e.target.value })}
                                onClick={(e) => e.currentTarget.showPicker?.()}
                                className="bg-slate-950 border border-slate-700 rounded px-1.5 py-1 text-xs text-amber-300 font-mono w-28 cursor-pointer"
                                title="Klik untuk membuka menu kalender tanggal"
                              />
                              <button
                                type="button"
                                onClick={() => setInlineData({ ...inlineData, jatemFakt: '' })}
                                className="p-1 bg-red-950/60 hover:bg-red-900 text-red-300 rounded cursor-pointer"
                                title="Hapus Jatuh Tempo (Batal Bayar)"
                              >
                                <X className="w-3 h-3" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setInlineData({ ...inlineData, jatemFakt: calculateJatuhTempo(todayStr, r.rumusHari || 30) })}
                                className="p-1 bg-emerald-950/60 hover:bg-emerald-900 text-emerald-300 rounded cursor-pointer"
                                title="Isi Ulang Jatuh Tempo Hari Ini"
                              >
                                <RotateCcw className="w-3 h-3" />
                              </button>
                            </div>
                          </td>

                          {/* TGL BAYAR */}
                          <td className="py-2.5 px-2">
                            <input
                              type="date"
                              value={inlineData.tglBayar !== undefined ? inlineData.tglBayar : r.tglBayar}
                              onChange={(e) => {
                                const val = e.target.value;
                                setInlineData({
                                  ...inlineData,
                                  tglBayar: val,
                                  statusBayar: val ? 'SUDAH BAYAR' : 'BELUM BAYAR'
                                });
                              }}
                              onClick={(e) => e.currentTarget.showPicker?.()}
                              className="bg-slate-950 border border-amber-400 rounded px-1.5 py-1 text-xs text-emerald-400 font-mono w-28 cursor-pointer"
                              title="Klik untuk membuka menu kalender tanggal"
                            />
                          </td>

                          {/* RODA */}
                          <td className="py-2.5 px-1">
                            <select
                              value={inlineData.roda || r.roda}
                              onChange={(e) => setInlineData({ ...inlineData, roda: e.target.value as RodaType })}
                              className="bg-slate-950 border border-slate-700 rounded p-1 text-[11px] text-white"
                            >
                              <option value="R2">R2</option>
                              <option value="R3">R3</option>
                              <option value="R4">R4</option>
                            </select>
                          </td>

                          {/* TRANSAKSI */}
                          <td className="py-2.5 px-2">
                            <select
                              value={inlineData.transaksi || r.transaksi}
                              onChange={(e) => setInlineData({ ...inlineData, transaksi: e.target.value as TransaksiType })}
                              className="bg-slate-950 border border-slate-700 rounded p-1 text-[11px] text-white"
                            >
                              <option value="CKD">CKD</option>
                              <option value="CBU">CBU</option>
                              <option value="GIIAS">GIIAS</option>
                              <option value="EX DUMP">EX DUMP</option>
                              <option value="LISTRIK/HYB">LISTRIK/HYB</option>
                            </select>
                          </td>

                          {/* PLAT */}
                          <td className="py-2.5 px-1">
                            <select
                              value={inlineData.plat || r.plat}
                              onChange={(e) => setInlineData({ ...inlineData, plat: e.target.value as PlatType })}
                              className="bg-slate-950 border border-slate-700 rounded p-1 text-[11px] text-white"
                            >
                              <option value="1">1</option>
                              <option value="2">2</option>
                              <option value="3">3</option>
                            </select>
                          </td>

                          {/* STATUS */}
                          <td className="py-2.5 px-2">
                            <select
                              value={inlineData.statusBayar || r.statusBayar}
                              onChange={(e) => {
                                const val = e.target.value as StatusBayar;
                                if (val === 'DIBATALKAN') {
                                  setInlineData({
                                    ...inlineData,
                                    statusBayar: val,
                                    tglBayar: '',
                                    jatemFakt: '', // Otomatis hapus saat dibatalkan
                                  });
                                } else if (val === 'SUDAH BAYAR') {
                                  setInlineData({
                                    ...inlineData,
                                    statusBayar: val,
                                    tglBayar: inlineData.tglBayar || todayStr,
                                    jatemFakt: inlineData.jatemFakt || calculateJatuhTempo(todayStr, r.rumusHari || 30),
                                  });
                                } else {
                                  setInlineData({
                                    ...inlineData,
                                    statusBayar: val,
                                    tglBayar: '',
                                  });
                                }
                              }}
                              className="bg-slate-950 border border-slate-700 rounded p-1 text-[11px] text-white font-bold"
                            >
                              <option value="SUDAH BAYAR">SUDAH BAYAR</option>
                              <option value="BELUM BAYAR">BELUM BAYAR</option>
                              <option value="DIBATALKAN">DIBATALKAN</option>
                            </select>
                          </td>

                          {/* EVIDENT */}
                          <td className="py-2.5 px-2 text-[10px] text-slate-400">
                            {r.evident ? 'Ada Foto' : '-'}
                          </td>

                          {/* LINK FILE */}
                          <td className="py-2.5 px-2">
                            <input
                              type="text"
                              value={inlineData.linkFile !== undefined ? inlineData.linkFile : r.linkFile}
                              onChange={(e) => setInlineData({ ...inlineData, linkFile: e.target.value })}
                              className="bg-slate-950 border border-slate-700 rounded px-1.5 py-1 text-xs text-white font-mono w-28"
                            />
                          </td>

                          {/* NOTE */}
                          <td className="py-2.5 px-2">
                            <input
                              type="text"
                              value={inlineData.note !== undefined ? inlineData.note : r.note}
                              onChange={(e) => setInlineData({ ...inlineData, note: e.target.value })}
                              className="bg-slate-950 border border-slate-700 rounded px-1.5 py-1 text-xs text-white w-32"
                            />
                          </td>

                          {/* SAVE / CANCEL */}
                          <td className="py-2.5 px-2 text-right">
                            <div className="flex items-center justify-end gap-1">
                              <button
                                onClick={() => saveInlineEdit(r)}
                                className="p-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded shadow"
                                title="Simpan Perubahan Langsung"
                              >
                                <Check className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={cancelInlineEdit}
                                className="p-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded"
                                title="Batal"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    }

                    // REGULAR READ-ONLY ROW
                    const isPaid = r.statusBayar === 'SUDAH BAYAR';

                    return (
                      <tr key={r.id} className="hover:bg-slate-850/50 transition-colors group">
                        
                        {/* No */}
                        <td className="py-2.5 px-3 text-center font-mono text-slate-500 text-[11px]">
                          {index + 1}
                        </td>

                        {/* TGL (Entri) */}
                        <td className="py-2.5 px-3 font-mono text-slate-300 whitespace-nowrap">
                          {r.tgl}
                        </td>

                        {/* NOPOL */}
                        <td className="py-2.5 px-3">
                          <span className="font-mono font-bold text-amber-300 whitespace-nowrap text-xs tracking-wider">
                            {r.nopol}
                          </span>
                        </td>

                        {/* NAMA */}
                        <td className="py-2.5 px-4 font-medium text-white truncate max-w-[150px]">
                          {r.nama}
                        </td>

                        {/* TGL FAKTUR */}
                        <td className="py-2.5 px-3 font-mono text-slate-400 whitespace-nowrap">
                          {r.tglFaktur}
                        </td>

                        {/* JATEM FAKT (RUMUS) */}
                        <td className="py-2.5 px-3 font-mono whitespace-nowrap">
                          {r.jatemFakt ? (
                            <span className="text-slate-300">{r.jatemFakt}</span>
                          ) : (
                            <span className="text-red-400 text-[11px] font-semibold italic">Dihapus (Batal)</span>
                          )}
                        </td>

                        {/* TGL BAYAR */}
                        <td className="py-2.5 px-3 font-mono whitespace-nowrap">
                          {r.tglBayar ? (
                            <span className="text-emerald-400 font-semibold">{r.tglBayar}</span>
                          ) : (
                            <span className="text-red-400 text-[11px]">- (Belum)</span>
                          )}
                        </td>

                        {/* RODA */}
                        <td className="py-2.5 px-2 text-center">
                          <span className="font-mono font-bold text-blue-300 bg-blue-950/60 px-1.5 py-0.5 rounded border border-blue-800/40 text-[11px]">
                            {r.roda}
                          </span>
                        </td>

                        {/* TRANSAKSI */}
                        <td className="py-2.5 px-3 font-mono text-[11px] text-slate-300 whitespace-nowrap">
                          {r.transaksi}
                        </td>

                        {/* PLAT */}
                        <td className="py-2.5 px-2 text-center">
                          <span className="font-mono font-bold text-amber-300 bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-800/40 text-[11px]">
                            {r.plat}
                          </span>
                        </td>

                        {/* STATUS BAYAR */}
                        <td className="py-2.5 px-3 whitespace-nowrap">
                          {isPaid ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800/60 font-mono">
                              <Check className="w-3 h-3 text-emerald-400" /> SUDAH BAYAR
                            </span>
                          ) : r.statusBayar === 'DIBATALKAN' ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-red-950 text-red-300 border border-red-800/60 font-mono">
                              <Clock className="w-3 h-3 text-red-400" /> BATAL BAYAR
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-800/60 font-mono">
                              <Clock className="w-3 h-3 text-amber-400" /> BELUM BAYAR
                            </span>
                          )}
                        </td>

                        {/* EVIDENT */}
                        <td className="py-2 px-3 text-center">
                          {showImageThumbnails ? (
                            <div className="flex items-center justify-center">
                              <button
                                type="button"
                                onClick={() => onOpenEvident(getEvidentImageUrl(r), `Dokumen Evident Arsip: ${r.nopol} (${r.nama})`)}
                                className="relative group/thumb block rounded overflow-hidden border border-slate-700 hover:border-amber-400 transition-all shadow hover:shadow-amber-400/20 cursor-pointer"
                                title="Klik untuk zoom & periksa foto dokumen"
                              >
                                <img
                                  src={getEvidentImageUrl(r)}
                                  alt={`Evident ${r.nopol}`}
                                  className="w-14 h-9 object-cover bg-slate-950"
                                />
                                <div className="absolute inset-0 bg-slate-950/60 opacity-0 group-hover/thumb:opacity-100 transition-opacity flex items-center justify-center">
                                  <Eye className="w-3.5 h-3.5 text-amber-300" />
                                </div>
                              </button>
                            </div>
                          ) : (
                            r.evident || r.evidentName ? (
                              <button
                                onClick={() => onOpenEvident(getEvidentImageUrl(r), `Evident Arsip ${r.nopol}`)}
                                className="p-1 text-blue-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
                                title="Pratinjau Foto Evident"
                              >
                                <Eye className="w-4 h-4" />
                              </button>
                            ) : (
                              <span className="text-[10px] text-slate-600">-</span>
                            )
                          )}
                        </td>

                        {/* LINK FILE */}
                        <td className="py-2.5 px-3">
                          {r.linkFile ? (
                            <button
                              onClick={() => handleCopyPath(r.linkFile)}
                              className="text-[11px] text-amber-300/90 hover:text-amber-200 font-mono truncate max-w-[130px] flex items-center gap-1 underline underline-offset-2"
                              title={`Salin alamat: ${r.linkFile}`}
                            >
                              <Folder className="w-3 h-3 shrink-0" />
                              <span className="truncate">{r.linkFile}</span>
                            </button>
                          ) : (
                            <span className="text-[10px] text-slate-600 italic">-</span>
                          )}
                        </td>

                        {/* NOTE / REASONING */}
                        <td className="py-2.5 px-4 text-[11px] text-slate-400 italic max-w-[180px] truncate">
                          {r.note || '-'}
                        </td>

                        {/* AKSI (Direct Inline Edit, Modal Edit, Delete) */}
                        <td className="py-2.5 px-3 text-right">
                          <div className="flex items-center justify-end gap-1 opacity-70 group-hover:opacity-100 transition-opacity">
                            
                            {/* Direct Inline Edit Button */}
                            <button
                              onClick={() => startInlineEdit(r)}
                              className="p-1 text-amber-400 hover:text-amber-300 rounded hover:bg-slate-800"
                              title="Edit langsung di tabel"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>

                            {/* Full Modal Edit Button */}
                            <button
                              onClick={() => onEditRecord(r)}
                              className="p-1 text-blue-400 hover:text-blue-300 rounded hover:bg-slate-800"
                              title="Buka form modal lengkap"
                            >
                              <FileText className="w-3.5 h-3.5" />
                            </button>

                            {/* Delete Button */}
                            <button
                              onClick={() => {
                                if (window.confirm(`Hapus data ${r.nopol}? Tindakan ini tidak dapat dibatalkan.`)) {
                                  onDeleteRecord(r.id);
                                }
                              }}
                              className="p-1 text-slate-500 hover:text-red-400 rounded hover:bg-slate-800"
                              title="Hapus data arsip"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>

                          </div>
                        </td>

                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          {/* Table Footer */}
          <div className="p-3 bg-slate-950 border-t border-slate-800 text-xs text-slate-400 flex flex-col sm:flex-row items-center justify-between gap-2">
            <div className="font-mono">
              Total Data: <span className="font-bold text-white tabular-nums">{filteredRecords.length}</span> baris
            </div>
            <div className="text-[11px] text-slate-500">
              Tip: Klik ikon pensil kuning pada baris untuk <strong className="text-amber-400">memasukkan atau mengedit data langsung</strong> di tabel respons.
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
