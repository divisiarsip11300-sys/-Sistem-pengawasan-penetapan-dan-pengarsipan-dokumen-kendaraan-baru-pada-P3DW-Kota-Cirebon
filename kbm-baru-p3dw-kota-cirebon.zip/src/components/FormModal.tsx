import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Camera, 
  Upload, 
  Folder, 
  Calendar, 
  AlertCircle, 
  Check, 
  RefreshCw, 
  Trash2, 
  RotateCcw, 
  CheckCircle2, 
  XCircle, 
  Clock 
} from 'lucide-react';
import { KbmRecord, RodaType, TransaksiType, PlatType, StatusBayar } from '../types/archive';
import { calculateJatuhTempo, getTodayDateString, getPlatLabel } from '../utils/formatters';
import { DatePickerField } from './DatePickerField';

interface FormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (record: KbmRecord) => void;
  initialRecord?: KbmRecord | null;
}

export const FormModal: React.FC<FormModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialRecord,
}) => {
  const todayStr = getTodayDateString();

  // Form states
  const [tgl, setTgl] = useState<string>(todayStr);
  const [nopol, setNopol] = useState<string>('');
  const [nama, setNama] = useState<string>('');
  const [tglFaktur, setTglFaktur] = useState<string>(todayStr);
  const [rumusHari, setRumusHari] = useState<number>(30);
  const [jatemFakt, setJatemFakt] = useState<string>('');
  const [statusBayar, setStatusBayar] = useState<StatusBayar>('SUDAH BAYAR');
  const [tglBayar, setTglBayar] = useState<string>(todayStr);
  const [roda, setRoda] = useState<RodaType>('R4');
  const [transaksi, setTransaksi] = useState<TransaksiType>('CKD');
  const [plat, setPlat] = useState<PlatType>('1');
  const [evident, setEvident] = useState<string>('');
  const [evidentName, setEvidentName] = useState<string>('');
  const [linkFile, setLinkFile] = useState<string>('');
  const [note, setNote] = useState<string>('');
  
  // Camera capture states
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string>('');
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Sync form when modal opens or initialRecord changes
  useEffect(() => {
    if (initialRecord) {
      setTgl(initialRecord.tgl || todayStr);
      setNopol(initialRecord.nopol || '');
      setNama(initialRecord.nama || '');
      setTglFaktur(initialRecord.tglFaktur || todayStr);
      setRumusHari(initialRecord.rumusHari || 30);
      setJatemFakt(initialRecord.jatemFakt || '');
      setStatusBayar(initialRecord.statusBayar || 'SUDAH BAYAR');
      setTglBayar(initialRecord.tglBayar || '');
      setRoda(initialRecord.roda || 'R4');
      setTransaksi(initialRecord.transaksi || 'CKD');
      setPlat(initialRecord.plat || '1');
      setEvident(initialRecord.evident || '');
      setEvidentName(initialRecord.evidentName || '');
      setLinkFile(initialRecord.linkFile || '');
      setNote(initialRecord.note || '');
    } else {
      // Reset to defaults for a new entry
      setTgl(todayStr);
      setNopol('');
      setNama('');
      setTglFaktur(todayStr);
      setRumusHari(30);
      setJatemFakt(calculateJatuhTempo(todayStr, 30));
      setStatusBayar('SUDAH BAYAR');
      setTglBayar(todayStr);
      setRoda('R4');
      setTransaksi('CKD');
      setPlat('1');
      setEvident('');
      setEvidentName('');
      setLinkFile(`D:\\ARSIP_SAMSAT_CIREBON\\${new Date().getFullYear()}\\KBM_BARU\\`);
      setNote('');
    }
    stopCamera();
  }, [initialRecord, isOpen]);

  // Handle switching status with smart date helpers
  const handleSelectStatus = (newStatus: StatusBayar) => {
    setStatusBayar(newStatus);
    if (newStatus === 'SUDAH BAYAR') {
      // Paying today: set tglBayar to today, refill jatemFakt if empty
      setTglBayar(todayStr);
      if (!jatemFakt) {
        setJatemFakt(calculateJatuhTempo(todayStr, rumusHari));
      }
    } else if (newStatus === 'DIBATALKAN') {
      // Batal bayar: clear tglBayar and clear jatemFakt (dihapus sesuai aturan batal bayar)
      setTglBayar('');
      setJatemFakt('');
    } else {
      // BELUM BAYAR: clear tglBayar, keep or allow recomputing jatemFakt
      setTglBayar('');
      if (!jatemFakt && tglFaktur) {
        setJatemFakt(calculateJatuhTempo(tglFaktur, rumusHari));
      }
    }
  };

  // Helper: Hapus Jatuh Tempo secara manual
  const handleClearJatem = () => {
    setJatemFakt('');
  };

  // Helper: Isi Ulang Jatuh Tempo Hari Ini (Rumus dari hari ini + interval)
  const handleRefillJatemToday = () => {
    const computed = calculateJatuhTempo(todayStr, rumusHari);
    setJatemFakt(computed);
  };

  // Helper: Hitung Ulang dari Tanggal Faktur
  const handleRecalculateFromFaktur = (customDays?: number) => {
    const days = customDays !== undefined ? customDays : rumusHari;
    if (tglFaktur) {
      setJatemFakt(calculateJatuhTempo(tglFaktur, days));
    }
  };

  // Auto-generate PC folder link when Nopol changes if user wants
  const handleAutoGeneratePath = () => {
    const cleanNopol = nopol.trim().replace(/\s+/g, '_').toUpperCase() || 'BERKAS_BARU';
    const year = new Date().getFullYear();
    setLinkFile(`D:\\ARSIP_SAMSAT_CIREBON\\${year}\\KBM_BARU\\${cleanNopol}.pdf`);
  };

  // Camera capture functions
  const startCamera = async () => {
    setCameraError('');
    setIsCameraActive(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err: unknown) {
      console.error('Camera error', err);
      setCameraError('Kamera tidak dapat diakses atau izin ditolak. Silakan gunakan unggah foto folder.');
      setIsCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
  };

  const capturePhoto = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 640;
    canvas.height = videoRef.current.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      setEvident(dataUrl);
      setEvidentName(`CAPTURE_${nopol || 'KBM'}_${Date.now()}.JPG`);
    }
    stopCamera();
  };

  // Upload file from folder handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setEvident(reader.result as string);
        setEvidentName(file.name);
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle submit
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nopol.trim()) {
      alert('Mohon isi Nomor Polisi kendaraan!');
      return;
    }
    if (!nama.trim()) {
      alert('Mohon isi Nama Pemilik / Wajib Pajak!');
      return;
    }

    const finalTglBayar = statusBayar === 'SUDAH BAYAR' ? (tglBayar || todayStr) : '';

    // Append audit reasoning if transitioning
    let finalNote = note.trim();
    if (initialRecord && initialRecord.statusBayar !== statusBayar) {
      if (statusBayar === 'SUDAH BAYAR' && (initialRecord.statusBayar === 'DIBATALKAN' || initialRecord.statusBayar === 'BELUM BAYAR')) {
        const audit = `[Dipulihkan & Membayar Hari Ini ${todayStr}]`;
        finalNote = finalNote ? `${finalNote} · ${audit}` : audit;
      } else if (statusBayar === 'DIBATALKAN') {
        const audit = `[Batal Membayar & Jatem Dihapus ${todayStr}]`;
        finalNote = finalNote ? `${finalNote} · ${audit}` : audit;
      }
    }

    const newRecord: KbmRecord = {
      id: initialRecord ? initialRecord.id : `kbm-crb-${Date.now()}`,
      tgl,
      nopol: nopol.toUpperCase().trim(),
      nama: nama.toUpperCase().trim(),
      tglFaktur,
      tglBayar: finalTglBayar,
      jatemFakt: jatemFakt.trim(),
      rumusHari,
      roda,
      transaksi,
      plat,
      statusBayar,
      evident,
      evidentName,
      linkFile: linkFile.trim(),
      note: finalNote,
      createdAt: initialRecord ? initialRecord.createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    onSave(newRecord);
    stopCamera();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-700 rounded-xl shadow-2xl text-slate-100 overflow-hidden my-8">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-850 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-8 h-10 shrink-0 flex items-center justify-center">
              <img
                src="/logo_jabar_transparan.png"
                alt="Logo Jawa Barat"
                className="w-full h-full object-contain drop-shadow"
              />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                {initialRecord ? 'Ubah Data Arsip KBM Baru' : 'Formulir Entri KBM Baru P3DW Kota Cirebon'}
              </h2>
              <p className="text-xs text-amber-300/90 font-medium">
                Pusat Pengelolaan Pendapatan Daerah Wilayah Kota Cirebon · Bapenda Jabar
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          
          {/* Section 1: Identitas & Tanggal */}
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="text-xs font-semibold text-amber-400 uppercase tracking-wider">
                1. Identitas Kendaraan &amp; Pendaftaran
              </h3>
              <span className="text-xs text-slate-400 font-mono">
                Tanggal Hari Ini: {todayStr}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* TGL ENTRI */}
              <div>
                <DatePickerField
                  label="TGL (Tanggal Entri)"
                  value={tgl}
                  onChange={setTgl}
                  required
                  helperText="Klik untuk memilih dari menu kalender"
                />
              </div>

              {/* NOPOL */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  NOPOL (Nomor Polisi) *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: E 2841 BQ"
                  value={nopol}
                  onChange={(e) => setNopol(e.target.value.toUpperCase())}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-amber-300 font-mono font-bold tracking-wider placeholder:text-slate-600 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400"
                />
              </div>

              {/* NAMA PEMILIK */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  NAMA (Pemilik / Wajib Pajak) *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Nama pemohon atau perusahaan"
                  value={nama}
                  onChange={(e) => setNama(e.target.value.toUpperCase())}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white placeholder:text-slate-600 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Status Pembayaran, Tanggal Faktur & Jatuh Tempo */}
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="text-xs font-semibold text-amber-400 uppercase tracking-wider">
                2. Status Pembayaran &amp; Tanggal Jatuh Tempo (Dapat Dihapus / Diisi Ulang)
              </h3>
            </div>

            {/* Status Bayar Selector: SUDAH BAYAR, BELUM BAYAR, DIBATALKAN */}
            <div className="bg-slate-950/80 border border-slate-800 p-3.5 rounded-xl space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <label className="text-xs font-semibold text-slate-200">
                  Status Pembayaran Kendaraan:
                </label>
                <span className="text-[11px] text-slate-400">
                  Pilih status untuk otomatis menyesuaikan tanggal bayar &amp; jatuh tempo
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {/* 1. SUDAH BAYAR */}
                <button
                  type="button"
                  onClick={() => handleSelectStatus('SUDAH BAYAR')}
                  className={`px-3 py-2.5 rounded-lg border text-left flex items-start gap-2.5 transition-all cursor-pointer ${
                    statusBayar === 'SUDAH BAYAR'
                      ? 'bg-emerald-950/80 border-emerald-500 text-white shadow-md'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
                  }`}
                >
                  <CheckCircle2 className={`w-4 h-4 shrink-0 mt-0.5 ${statusBayar === 'SUDAH BAYAR' ? 'text-emerald-400' : 'text-slate-500'}`} />
                  <div>
                    <div className="text-xs font-bold text-emerald-400">SUDAH BAYAR</div>
                    <div className="text-[10px] text-slate-400">Tgl Bayar hari ini, Jatem diisi ulang</div>
                  </div>
                </button>

                {/* 2. BELUM BAYAR */}
                <button
                  type="button"
                  onClick={() => handleSelectStatus('BELUM BAYAR')}
                  className={`px-3 py-2.5 rounded-lg border text-left flex items-start gap-2.5 transition-all cursor-pointer ${
                    statusBayar === 'BELUM BAYAR'
                      ? 'bg-amber-950/80 border-amber-500 text-white shadow-md'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
                  }`}
                >
                  <Clock className={`w-4 h-4 shrink-0 mt-0.5 ${statusBayar === 'BELUM BAYAR' ? 'text-amber-400' : 'text-slate-500'}`} />
                  <div>
                    <div className="text-xs font-bold text-amber-300">BELUM BAYAR</div>
                    <div className="text-[10px] text-slate-400">Tgl Bayar kosong, masuk tabel kontrol</div>
                  </div>
                </button>

                {/* 3. DIBATALKAN (BATAL BAYAR) */}
                <button
                  type="button"
                  onClick={() => handleSelectStatus('DIBATALKAN')}
                  className={`px-3 py-2.5 rounded-lg border text-left flex items-start gap-2.5 transition-all cursor-pointer ${
                    statusBayar === 'DIBATALKAN'
                      ? 'bg-red-950/80 border-red-500 text-white shadow-md'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
                  }`}
                >
                  <XCircle className={`w-4 h-4 shrink-0 mt-0.5 ${statusBayar === 'DIBATALKAN' ? 'text-red-400' : 'text-slate-500'}`} />
                  <div>
                    <div className="text-xs font-bold text-red-400">DIBATALKAN (Batal Bayar)</div>
                    <div className="text-[10px] text-slate-400">Jatuh tempo dihapus &amp; tgl bayar kosong</div>
                  </div>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* TGL FAKTUR */}
              <div>
                <DatePickerField
                  label="TGL FAKTUR (Tanggal Faktur)"
                  value={tglFaktur}
                  onChange={(val) => {
                    setTglFaktur(val);
                    // If not cancelled and user wants auto recalculation
                    if (statusBayar !== 'DIBATALKAN') {
                      setJatemFakt(calculateJatuhTempo(val, rumusHari));
                    }
                  }}
                  required
                  helperText="Klik untuk membuka menu kalender"
                />
              </div>

              {/* JATEM FAKT (EDITABLE, DAPAT DIHAPUS JIKA BATAL, DAN DIISI ULANG HARI INI JIKA MEMBAYAR) */}
              <div className="bg-slate-950/70 border border-slate-800 p-2.5 rounded-lg space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-200">
                    JATEM FAKT (Jatuh Tempo)
                  </label>
                  <div className="flex items-center gap-1">
                    {[14, 30, 60].map((d) => (
                      <button
                        type="button"
                        key={d}
                        onClick={() => {
                          setRumusHari(d);
                          if (statusBayar === 'SUDAH BAYAR') {
                            setJatemFakt(calculateJatuhTempo(todayStr, d));
                          } else {
                            setJatemFakt(calculateJatuhTempo(tglFaktur, d));
                          }
                        }}
                        className={`px-1.5 py-0.5 text-[10px] rounded font-mono ${
                          rumusHari === d
                            ? 'bg-amber-500 text-slate-950 font-bold'
                            : 'bg-slate-800 text-slate-400 hover:text-white'
                        }`}
                        title={`Set interval +${d} hari`}
                      >
                        +{d}H
                      </button>
                    ))}
                  </div>
                </div>

                {/* Date Picker Field with Popup Calendar Menu */}
                <DatePickerField
                  value={jatemFakt}
                  onChange={setJatemFakt}
                  allowClear={true}
                  placeholder="Jatuh tempo kosong/dihapus"
                  presets={[
                    { label: '+14H', days: 14 },
                    { label: '+30H', days: 30 },
                    { label: '+60H', days: 60 }
                  ]}
                  presetReferenceDate={tglFaktur || todayStr}
                />

                {/* Helper action buttons to Clear (Hapus) or Refill (Isi Ulang Hari Ini) */}
                <div className="flex items-center justify-between pt-1 gap-1.5">
                  <button
                    type="button"
                    onClick={handleClearJatem}
                    className="px-2 py-1 bg-red-950/60 hover:bg-red-900/80 text-red-300 border border-red-800/60 rounded text-[10px] font-medium flex items-center gap-1 transition-colors cursor-pointer"
                    title="Hapus tanggal jatuh tempo (khusus jika batal bayar)"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>Hapus Jatem</span>
                  </button>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={handleRefillJatemToday}
                      className="px-2 py-1 bg-emerald-950/60 hover:bg-emerald-900/80 text-emerald-300 border border-emerald-800/60 rounded text-[10px] font-medium flex items-center gap-1 transition-colors cursor-pointer"
                      title="Isi ulang tanggal jatuh tempo terhitung dari hari ini (+30 hari)"
                    >
                      <RotateCcw className="w-3 h-3 text-emerald-400" />
                      <span>Isi Ulang Hari Ini</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRecalculateFromFaktur()}
                      className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[10px] font-medium flex items-center gap-1 transition-colors cursor-pointer"
                      title="Hitung dari tanggal faktur"
                    >
                      <span>Dari Faktur</span>
                    </button>
                  </div>
                </div>

                <p className="text-[10px] text-slate-400 leading-tight">
                  {jatemFakt ? (
                    <>Jatuh tempo aktif: <strong className="text-amber-300 font-mono">{jatemFakt}</strong></>
                  ) : (
                    <span className="text-amber-400 font-medium">Jatuh tempo telah dihapus. Klik menu kalender atau "Isi Ulang Hari Ini" saat kendaraan membayar hari ini.</span>
                  )}
                </p>
              </div>

              {/* TGL BAYAR (DEFAULT HARI INI KHUSUS DATA BARU) */}
              <div className="bg-slate-950/70 border border-slate-800 p-2.5 rounded-lg space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-200">
                    TGL BAYAR (Data Baru: Otomatis Today)
                  </label>
                  {statusBayar === 'SUDAH BAYAR' && (
                    <span className="text-[10px] text-emerald-400 font-mono font-bold">
                      LUNAS
                    </span>
                  )}
                </div>

                {statusBayar === 'SUDAH BAYAR' ? (
                  <div className="space-y-1.5">
                    <DatePickerField
                      value={tglBayar}
                      onChange={(val) => {
                        setTglBayar(val);
                        if (val && !jatemFakt) {
                          setJatemFakt(calculateJatuhTempo(val, rumusHari));
                        }
                      }}
                      placeholder="Pilih tanggal bayar..."
                      allowClear={true}
                    />
                    <div className="flex justify-between items-center text-[10px]">
                      <span className="text-slate-400">Data baru otomatis: <strong>today()</strong></span>
                      <button
                        type="button"
                        onClick={() => setTglBayar(todayStr)}
                        className="text-amber-400 hover:text-amber-300 font-mono font-bold cursor-pointer"
                      >
                        Set Hari Ini ({todayStr})
                      </button>
                    </div>
                  </div>
                ) : statusBayar === 'DIBATALKAN' ? (
                  <div className="bg-red-950/40 border border-red-900/60 rounded p-2 text-xs text-red-300 space-y-1">
                    <div className="font-semibold flex items-center gap-1">
                      <XCircle className="w-3.5 h-3.5" />
                      Status: BATAL MEMBAYAR
                    </div>
                    <p className="text-[10px] text-red-400/90 leading-tight">
                      Tanggal bayar dikosongkan dan jatuh tempo dapat dihapus. Untuk melunasi hari ini, klik tombol "SUDAH BAYAR" di atas.
                    </p>
                  </div>
                ) : (
                  <div className="bg-amber-950/40 border border-amber-900/60 rounded p-2 text-xs text-amber-300 space-y-1">
                    <div className="font-semibold flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      Status: BELUM BAYAR
                    </div>
                    <p className="text-[10px] text-amber-400/90 leading-tight">
                      Tgl Bayar kosong, berkas dipantau pada tabel kontrol kendaraan belum membayar.
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Section 3: Enum Lists (RODA, TRANSAKSI, PLAT) */}
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="text-xs font-semibold text-amber-400 uppercase tracking-wider">
                3. Klasifikasi KBM (Roda, Transaksi &amp; Plat)
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* RODA: R2, R3, R4 */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  RODA (Enum: R2, R3, R4) *
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['R2', 'R3', 'R4'] as RodaType[]).map((r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setRoda(r)}
                      className={`py-2 px-2 text-xs font-bold rounded-lg border transition-all ${
                        roda === r
                          ? 'bg-blue-600 border-blue-400 text-white shadow-sm'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
                      }`}
                    >
                      {r}
                      <span className="block text-[10px] font-normal opacity-80">
                        {r === 'R2' ? 'Motor' : r === 'R3' ? 'Tiga Roda' : 'Mobil/Truk'}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* TRANSAKSI: CKD, CBU, GIIAS, EX DUMP, LISTRIK/HYB */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  TRANSAKSI (Jenis Pengadaan) *
                </label>
                <select
                  value={transaksi}
                  onChange={(e) => setTransaksi(e.target.value as TransaksiType)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 font-mono"
                >
                  <option value="CKD">CKD (Completely Knocked Down)</option>
                  <option value="CBU">CBU (Completely Built Up - Impor)</option>
                  <option value="GIIAS">GIIAS (Pameran Otomotif)</option>
                  <option value="EX DUMP">EX DUMP (Pelepasan Aset / Lelang)</option>
                  <option value="LISTRIK/HYB">LISTRIK/HYB (Kendaraan Listrik &amp; Hybrid)</option>
                </select>
              </div>

              {/* PLAT: 1, 2, 3 */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  PLAT (Enum: 1, 2, 3) *
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['1', '2', '3'] as PlatType[]).map((p) => (
                    <button
                      key={p}
                      type="button"
                      onClick={() => setPlat(p)}
                      className={`py-2 px-1 text-xs font-bold rounded-lg border text-center transition-all ${
                        plat === p
                          ? 'bg-amber-500 border-amber-300 text-slate-950 shadow-sm'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
                      }`}
                    >
                      Plat {p}
                      <span className="block text-[9px] font-normal truncate">
                        {p === '1' ? 'Hitam/Pribadi' : p === '2' ? 'Kuning/Umum' : 'Merah/Dinas'}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Section 4: Evident (Folder Upload / Capture Kamera) & Link File Folder PC */}
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="text-xs font-semibold text-amber-400 uppercase tracking-wider">
                4. Evident (Capture / Upload) &amp; Link File Folder PC
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              
              {/* EVIDENT */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-200">
                    Foto Evident / Dokumen Arsip
                  </span>
                  {evident && (
                    <button
                      type="button"
                      onClick={() => {
                        setEvident('');
                        setEvidentName('');
                      }}
                      className="text-[11px] text-red-400 hover:text-red-300"
                    >
                      Hapus Foto
                    </button>
                  )}
                </div>

                {/* Camera Viewport or Preview */}
                {isCameraActive ? (
                  <div className="relative rounded-lg overflow-hidden border border-amber-400 bg-black aspect-video flex flex-col items-center justify-center">
                    <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
                    <div className="absolute bottom-3 flex gap-2">
                      <button
                        type="button"
                        onClick={capturePhoto}
                        className="px-4 py-1.5 bg-amber-400 text-slate-950 font-bold text-xs rounded-full shadow-lg hover:bg-amber-300 active:scale-95 flex items-center gap-1.5"
                      >
                        <Camera className="w-4 h-4" />
                        Ambil Foto
                      </button>
                      <button
                        type="button"
                        onClick={stopCamera}
                        className="px-3 py-1.5 bg-slate-800 text-white text-xs rounded-full hover:bg-slate-700"
                      >
                        Batal
                      </button>
                    </div>
                  </div>
                ) : evident ? (
                  <div className="relative rounded-lg overflow-hidden border border-slate-700 aspect-video bg-black flex items-center justify-center group">
                    <img src={evident} alt="Evident Preview" className="w-full h-full object-contain" />
                    <div className="absolute inset-0 bg-slate-950/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                      <button
                        type="button"
                        onClick={startCamera}
                        className="px-3 py-1 text-xs bg-slate-800 text-white rounded hover:bg-slate-700 flex items-center gap-1"
                      >
                        <RefreshCw className="w-3.5 h-3.5" /> Ganti Kamera
                      </button>
                    </div>
                    {evidentName && (
                      <div className="absolute bottom-1 left-2 text-[10px] bg-slate-900/80 px-2 py-0.5 rounded text-slate-300 font-mono truncate max-w-[80%]">
                        {evidentName}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="border border-dashed border-slate-700 rounded-lg p-4 text-center space-y-3">
                    <div className="flex justify-center gap-3">
                      <button
                        type="button"
                        onClick={startCamera}
                        className="flex items-center gap-1.5 px-3 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow transition-colors"
                      >
                        <Camera className="w-4 h-4 text-amber-300" />
                        Capture Kamera
                      </button>
                      <label className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg cursor-pointer transition-colors">
                        <Upload className="w-4 h-4 text-slate-400" />
                        Ambil dari Folder
                        <input
                          type="file"
                          accept="image/*,.pdf"
                          onChange={handleFileUpload}
                          className="hidden"
                        />
                      </label>
                    </div>
                    <p className="text-[11px] text-slate-500">
                      Ambil foto fisik faktur/STNK atau upload file scan arsip
                    </p>
                  </div>
                )}
                {cameraError && (
                  <p className="text-xs text-red-400 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    {cameraError}
                  </p>
                )}
              </div>

              {/* LINK FILE DARI ALAMAT LINK FOLDER PADA PC SAYA */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                    <Folder className="w-4 h-4 text-amber-400" />
                    Link File / Alamat Folder PC
                  </span>
                  <button
                    type="button"
                    onClick={handleAutoGeneratePath}
                    className="text-[11px] text-blue-400 hover:text-blue-300 font-medium"
                  >
                    Format Otomatis Sesuai Nopol
                  </button>
                </div>

                <div className="space-y-1.5">
                  <input
                    type="text"
                    placeholder="Contoh: D:\ARSIP_SAMSAT\2026\E_2841_BQ.pdf"
                    value={linkFile}
                    onChange={(e) => setLinkFile(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-amber-300 font-mono placeholder:text-slate-600 focus:outline-none focus:border-blue-500"
                  />
                  <p className="text-[10px] text-slate-500">
                    Alamat folder penyimpanan berkas arsip lokal pada komputer (PC) Anda untuk mempermudah penelusuran fisik/PDF.
                  </p>
                </div>

                {/* Quick Presets */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  <span className="text-[10px] text-slate-400">Template Drive:</span>
                  {['D:\\ARSIP_SAMSAT\\KBM_BARU\\', 'C:\\SAMSAT_CIREBON\\ARSIP\\', 'Z:\\SERVER_P3DW\\KBM_2026\\'].map(p => (
                    <button
                      key={p}
                      type="button"
                      onClick={() => setLinkFile(p + (nopol ? `${nopol.replace(/\s+/g, '_')}.pdf` : ''))}
                      className="text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-0.5 rounded font-mono"
                    >
                      {p.split('\\')[0]}\\...
                    </button>
                  ))}
                </div>
              </div>

            </div>
          </div>

          {/* Section 5: NOTE (Reasoning Pengguna) */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-amber-400 uppercase tracking-wider">
              5. NOTE / Reasoning Petugas (Alasan Bayar / Penundaan / Batal Bayar)
            </label>
            <textarea
              rows={3}
              placeholder="Tuliskan catatan reasoning: alasan batal bayar, penundaan, verifikasi berkas dealer, pelunasan hari ini, dll..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-sm text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-amber-400"
            />
          </div>

          {/* Modal Footer / Action */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-800">
            <div className="text-xs text-slate-400">
              Klasifikasi: <span className="font-semibold text-white">{roda}</span> · <span className="font-semibold text-white">{transaksi}</span> · <span className="font-semibold text-white">{getPlatLabel(plat)}</span>
            </div>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => {
                  stopCamera();
                  onClose();
                }}
                className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
              >
                Batal
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 active:scale-95 rounded-lg shadow-md transition-all flex items-center gap-2 cursor-pointer"
              >
                <Check className="w-4 h-4 stroke-[3]" />
                {initialRecord ? 'Simpan Perubahan Arsip' : 'Daftarkan Arsip KBM Baru'}
              </button>
            </div>
          </div>

        </form>

      </div>
    </div>
  );
};
