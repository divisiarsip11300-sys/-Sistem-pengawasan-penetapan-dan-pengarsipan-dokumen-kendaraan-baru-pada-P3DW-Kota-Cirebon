import React from 'react';
import { X, Download, ZoomIn, ZoomOut, RotateCw } from 'lucide-react';

interface EvidentModalProps {
  isOpen: boolean;
  onClose: () => void;
  imageUrl: string;
  title: string;
}

export const EvidentModal: React.FC<EvidentModalProps> = ({
  isOpen,
  onClose,
  imageUrl,
  title,
}) => {
  const [zoom, setZoom] = React.useState<number>(1);
  const [rotation, setRotation] = React.useState<number>(0);

  if (!isOpen || !imageUrl) return null;

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = `${title.replace(/\s+/g, '_')}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-700 rounded-xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 bg-slate-950 border-b border-slate-800 text-white">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-amber-400 font-mono">EVIDENT ARSIP:</span>
            <span className="text-sm font-semibold text-white truncate max-w-md">{title}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setZoom(prev => Math.min(prev + 0.25, 3))}
              className="p-1.5 text-slate-400 hover:text-white rounded hover:bg-slate-800"
              title="Perbesar"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button
              onClick={() => setZoom(prev => Math.max(prev - 0.25, 0.5))}
              className="p-1.5 text-slate-400 hover:text-white rounded hover:bg-slate-800"
              title="Perkecil"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <button
              onClick={() => setRotation(prev => (prev + 90) % 360)}
              className="p-1.5 text-slate-400 hover:text-white rounded hover:bg-slate-800"
              title="Putar 90 Derajat"
            >
              <RotateCw className="w-4 h-4" />
            </button>
            <button
              onClick={handleDownload}
              className="p-1.5 text-blue-400 hover:text-blue-300 rounded hover:bg-slate-800"
              title="Unduh Berkas Gambar"
            >
              <Download className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded hover:bg-slate-800 ml-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Image Viewport */}
        <div className="flex-1 overflow-auto p-4 flex items-center justify-center bg-black min-h-[350px]">
          <img
            src={imageUrl}
            alt={title}
            style={{
              transform: `scale(${zoom}) rotate(${rotation}deg)`,
              transition: 'transform 0.15s ease-out'
            }}
            className="max-w-full max-h-[70vh] object-contain select-none"
          />
        </div>

        {/* Footer */}
        <div className="px-5 py-2.5 bg-slate-950 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
          <span>Skala Zoom: {Math.round(zoom * 100)}% · Rotasi: {rotation}°</span>
          <span>Dokumen Fisik Terverifikasi P3DW Samsat Kota Cirebon</span>
        </div>

      </div>
    </div>
  );
};
