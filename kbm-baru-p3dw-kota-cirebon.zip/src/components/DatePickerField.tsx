import React, { useState, useRef, useEffect } from 'react';
import { Calendar, ChevronLeft, ChevronRight, X, RotateCcw, Check } from 'lucide-react';
import { getTodayDateString, formatIndoDate } from '../utils/formatters';

interface DatePickerFieldProps {
  label?: string;
  value: string; // 'YYYY-MM-DD' or ''
  onChange: (dateStr: string) => void;
  required?: boolean;
  disabled?: boolean;
  placeholder?: string;
  allowClear?: boolean;
  helperText?: string;
  className?: string;
  inputClassName?: string;
  presets?: { label: string; days: number }[];
  presetReferenceDate?: string; // used to compute presets from a base date like tglFaktur
}

const MONTH_NAMES = [
  'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
  'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
];

const DAY_NAMES = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];

export const DatePickerField: React.FC<DatePickerFieldProps> = ({
  label,
  value,
  onChange,
  required = false,
  disabled = false,
  placeholder = 'Pilih tanggal...',
  allowClear = false,
  helperText,
  className = '',
  inputClassName = '',
  presets,
  presetReferenceDate,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const todayStr = getTodayDateString();

  // Parse initial view year and month from value or today
  const parseYearMonth = (val: string) => {
    if (val && val.includes('-')) {
      const parts = val.split('-');
      if (parts.length === 3) {
        return {
          year: parseInt(parts[0], 10),
          month: parseInt(parts[1], 10) - 1, // 0-indexed
        };
      }
    }
    const d = new Date();
    return { year: d.getFullYear(), month: d.getMonth() };
  };

  const initial = parseYearMonth(value);
  const [viewYear, setViewYear] = useState<number>(initial.year);
  const [viewMonth, setViewMonth] = useState<number>(initial.month);

  // Sync calendar view month/year when value changes or when opened
  useEffect(() => {
    if (isOpen) {
      const current = parseYearMonth(value);
      setViewYear(current.year);
      setViewMonth(current.month);
    }
  }, [isOpen, value]);

  // Close calendar popover when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  // Navigate months
  const handlePrevMonth = () => {
    if (viewMonth === 0) {
      setViewMonth(11);
      setViewYear(prev => prev - 1);
    } else {
      setViewMonth(prev => prev - 1);
    }
  };

  const handleNextMonth = () => {
    if (viewMonth === 11) {
      setViewMonth(0);
      setViewYear(prev => prev + 1);
    } else {
      setViewMonth(prev => prev + 1);
    }
  };

  // Build grid of days for current month
  const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
  const firstDayWeekday = new Date(viewYear, viewMonth, 1).getDay(); // 0 is Sunday

  // Days from previous month to fill the first row
  const daysInPrevMonth = new Date(viewYear, viewMonth, 0).getDate();
  const prevMonthDays = [];
  for (let i = firstDayWeekday - 1; i >= 0; i--) {
    prevMonthDays.push(daysInPrevMonth - i);
  }

  // Current month days
  const currentMonthDays = [];
  for (let d = 1; d <= daysInMonth; d++) {
    currentMonthDays.push(d);
  }

  // Next month days to complete grid (up to 42 cells or multiple of 7)
  const totalSlotsSoFar = prevMonthDays.length + currentMonthDays.length;
  const nextMonthDaysCount = (7 - (totalSlotsSoFar % 7)) % 7;
  const nextMonthDays = [];
  for (let d = 1; d <= nextMonthDaysCount; d++) {
    nextMonthDays.push(d);
  }

  // Format helper to YYYY-MM-DD
  const formatDateString = (year: number, month: number, day: number) => {
    const y = year;
    const m = String(month + 1).padStart(2, '0');
    const d = String(day).padStart(2, '0');
    return `${y}-${m}-${d}`;
  };

  const handleSelectDay = (day: number) => {
    const dateStr = formatDateString(viewYear, viewMonth, day);
    onChange(dateStr);
    setIsOpen(false);
  };

  const handleSelectToday = () => {
    onChange(todayStr);
    const [y, m] = todayStr.split('-').map(Number);
    setViewYear(y);
    setViewMonth(m - 1);
    setIsOpen(false);
  };

  const handleClear = () => {
    onChange('');
    setIsOpen(false);
  };

  // Quick preset calculation (+14, +30, +60 days)
  const handleApplyPreset = (days: number) => {
    const baseStr = presetReferenceDate || value || todayStr;
    const parts = baseStr.split('-');
    if (parts.length === 3) {
      const baseDate = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
      baseDate.setDate(baseDate.getDate() + days);
      const res = formatDateString(baseDate.getFullYear(), baseDate.getMonth(), baseDate.getDate());
      onChange(res);
      setViewYear(baseDate.getFullYear());
      setViewMonth(baseDate.getMonth());
      setIsOpen(false);
    }
  };

  return (
    <div className={`relative ${className}`} ref={containerRef}>
      {label && (
        <label className="block text-xs font-medium text-slate-300 mb-1.5 flex items-center justify-between">
          <span>{label} {required && <span className="text-red-400">*</span>}</span>
          {value && (
            <span className="text-[10px] text-amber-400 font-normal">
              {formatIndoDate(value)}
            </span>
          )}
        </label>
      )}

      {/* Input Display Box */}
      <div className="relative">
        <button
          type="button"
          disabled={disabled}
          onClick={() => !disabled && setIsOpen(!isOpen)}
          className={`w-full bg-slate-950 border text-left rounded-lg px-3 py-2 text-xs font-mono flex items-center justify-between transition-all cursor-pointer ${
            disabled 
              ? 'bg-slate-900 border-slate-800 text-slate-500 cursor-not-allowed' 
              : isOpen 
                ? 'border-amber-400 ring-1 ring-amber-400 text-white' 
                : 'border-slate-700 hover:border-slate-500 text-white'
          } ${inputClassName}`}
        >
          <div className="flex items-center gap-2 truncate">
            <Calendar className={`w-4 h-4 shrink-0 ${value ? 'text-amber-400' : 'text-slate-500'}`} />
            {value ? (
              <span className="font-semibold text-amber-300 tracking-wider">
                {value}
              </span>
            ) : (
              <span className="text-slate-500 italic">
                {placeholder}
              </span>
            )}
          </div>

          <div className="flex items-center gap-1 shrink-0 ml-1">
            {value && allowClear && !disabled && (
              <span
                role="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleClear();
                }}
                title="Hapus tanggal"
                className="p-1 hover:text-red-400 text-slate-500 rounded hover:bg-slate-800 transition-colors"
              >
                <X className="w-3.5 h-3.5" />
              </span>
            )}
            <span className="text-[10px] bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded font-sans hover:bg-slate-700">
              Buka Kalender
            </span>
          </div>
        </button>
      </div>

      {helperText && (
        <p className="text-[10px] text-slate-500 mt-1">{helperText}</p>
      )}

      {/* POPUP MENU TANGGALAN (INTERAKTIF & MUDAH DIKLIK) */}
      {isOpen && (
        <div className="absolute left-0 mt-1.5 w-72 sm:w-80 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl p-3.5 z-50 animate-in fade-in zoom-in-95 duration-100 space-y-3">
          
          {/* Calendar Header: Month & Year navigation */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
            <button
              type="button"
              onClick={handlePrevMonth}
              className="p-1 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition-colors"
              title="Bulan sebelumnya"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-1.5">
              {/* Month selector */}
              <select
                value={viewMonth}
                onChange={(e) => setViewMonth(parseInt(e.target.value, 10))}
                className="bg-slate-950 border border-slate-700 rounded px-2 py-1 text-xs text-white font-medium focus:outline-none focus:border-amber-400"
              >
                {MONTH_NAMES.map((name, idx) => (
                  <option key={name} value={idx}>{name}</option>
                ))}
              </select>

              {/* Year selector */}
              <select
                value={viewYear}
                onChange={(e) => setViewYear(parseInt(e.target.value, 10))}
                className="bg-slate-950 border border-slate-700 rounded px-2 py-1 text-xs text-white font-medium focus:outline-none focus:border-amber-400 font-mono"
              >
                {Array.from({ length: 15 }, (_, i) => 2020 + i).map(yr => (
                  <option key={yr} value={yr}>{yr}</option>
                ))}
              </select>
            </div>

            <button
              type="button"
              onClick={handleNextMonth}
              className="p-1 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition-colors"
              title="Bulan berikutnya"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Weekday Names Row */}
          <div className="grid grid-cols-7 gap-1 text-center">
            {DAY_NAMES.map((day, idx) => (
              <span
                key={day}
                className={`text-[11px] font-semibold py-1 ${
                  idx === 0 ? 'text-red-400' : 'text-slate-400'
                }`}
              >
                {day}
              </span>
            ))}
          </div>

          {/* Days Grid */}
          <div className="grid grid-cols-7 gap-1">
            {/* Days of previous month */}
            {prevMonthDays.map((d, i) => (
              <div
                key={`prev-${i}`}
                className="h-8 flex items-center justify-center text-xs text-slate-600 cursor-not-allowed select-none"
              >
                {d}
              </div>
            ))}

            {/* Days of current month */}
            {currentMonthDays.map((d) => {
              const dateStr = formatDateString(viewYear, viewMonth, d);
              const isSelected = value === dateStr;
              const isToday = todayStr === dateStr;
              const weekday = new Date(viewYear, viewMonth, d).getDay();
              const isSunday = weekday === 0;

              return (
                <button
                  type="button"
                  key={`cur-${d}`}
                  onClick={() => handleSelectDay(d)}
                  className={`h-8 w-full rounded-lg text-xs font-mono font-medium flex items-center justify-center transition-all cursor-pointer relative ${
                    isSelected
                      ? 'bg-amber-400 text-slate-950 font-bold shadow-md shadow-amber-400/20'
                      : isToday
                        ? 'bg-blue-600/30 border border-blue-500 text-blue-200 hover:bg-blue-600 hover:text-white'
                        : isSunday
                          ? 'text-red-400 hover:bg-slate-800 hover:text-red-300'
                          : 'text-slate-200 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  {d}
                  {isToday && !isSelected && (
                    <span className="absolute bottom-1 w-1 h-1 rounded-full bg-blue-400" />
                  )}
                </button>
              );
            })}

            {/* Days of next month */}
            {nextMonthDays.map((d, i) => (
              <div
                key={`next-${i}`}
                className="h-8 flex items-center justify-center text-xs text-slate-600 cursor-not-allowed select-none"
              >
                {d}
              </div>
            ))}
          </div>

          {/* Presets (like +14, +30, +60 days) if provided */}
          {presets && presets.length > 0 && (
            <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
              <span className="text-[10px] text-slate-400">Rumus:</span>
              <div className="flex gap-1">
                {presets.map(p => (
                  <button
                    key={p.label}
                    type="button"
                    onClick={() => handleApplyPreset(p.days)}
                    className="px-2 py-0.5 text-[10px] bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-slate-300 rounded font-mono transition-colors"
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Action Footer: Hari Ini (today), Hapus, Tutup */}
          <div className="pt-2.5 border-t border-slate-800 flex items-center justify-between gap-1 text-xs">
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={handleSelectToday}
                className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white text-[11px] font-semibold rounded shadow-sm transition-colors cursor-pointer"
                title="Pilih tanggal hari ini"
              >
                Hari Ini ({todayStr})
              </button>

              {allowClear && (
                <button
                  type="button"
                  onClick={handleClear}
                  className="px-2 py-1 bg-red-950/60 hover:bg-red-900 text-red-300 border border-red-800/60 text-[11px] rounded transition-colors cursor-pointer"
                  title="Kosongkan tanggal"
                >
                  Hapus
                </button>
              )}
            </div>

            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] rounded transition-colors"
            >
              Tutup
            </button>
          </div>

        </div>
      )}
    </div>
  );
};
