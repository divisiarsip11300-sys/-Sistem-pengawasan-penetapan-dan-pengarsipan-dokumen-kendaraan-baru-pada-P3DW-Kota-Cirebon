import React, { useState, useMemo } from 'react';
import { 
  BarChart3, 
  Calendar, 
  Download, 
  FileSpreadsheet, 
  Printer, 
  FileText, 
  CheckCircle2, 
  XCircle, 
  TrendingUp,
  Award,
  Layers
} from 'lucide-react';
import { KbmRecord } from '../types/archive';
import { formatIndoDate, exportToCSV, exportToExcel, getTodayDateString } from '../utils/formatters';

interface ReportsViewProps {
  records: KbmRecord[];
  onPrintPreview: () => void;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  records,
  onPrintPreview,
}) => {
  const [reportTab, setReportTab] = useState<'daily' | 'monthly' | 'annual'>('monthly');
  const [selectedYear, setSelectedYear] = useState<number>(2026);

  // Month names in Indonesian
  const monthNames = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];

  // Daily recap data
  const dailyRecap = useMemo(() => {
    const map = new Map<string, {
      date: string;
      total: number;
      paid: number;
      unpaid: number;
      r2: number;
      r3: number;
      r4: number;
      ckd: number;
      cbu: number;
      giias: number;
      exdump: number;
      ev: number;
    }>();

    records.forEach(r => {
      const d = r.tgl || 'Tanpa Tanggal';
      const cur = map.get(d) || {
        date: d,
        total: 0,
        paid: 0,
        unpaid: 0,
        r2: 0,
        r3: 0,
        r4: 0,
        ckd: 0,
        cbu: 0,
        giias: 0,
        exdump: 0,
        ev: 0,
      };

      cur.total += 1;
      if (r.statusBayar === 'SUDAH BAYAR') cur.paid += 1;
      else cur.unpaid += 1;

      if (r.roda === 'R2') cur.r2 += 1;
      else if (r.roda === 'R3') cur.r3 += 1;
      else if (r.roda === 'R4') cur.r4 += 1;

      if (r.transaksi === 'CKD') cur.ckd += 1;
      else if (r.transaksi === 'CBU') cur.cbu += 1;
      else if (r.transaksi === 'GIIAS') cur.giias += 1;
      else if (r.transaksi === 'EX DUMP') cur.exdump += 1;
      else if (r.transaksi === 'LISTRIK/HYB') cur.ev += 1;

      map.set(d, cur);
    });

    return Array.from(map.values()).sort((a, b) => b.date.localeCompare(a.date));
  }, [records]);

  // Monthly recap data (12 months of selectedYear)
  const monthlyRecap = useMemo(() => {
    return monthNames.map((name, index) => {
      const monthNum = String(index + 1).padStart(2, '0');
      const prefix = `${selectedYear}-${monthNum}`;

      const monthRecords = records.filter(r => (r.tgl || '').startsWith(prefix));
      const total = monthRecords.length;
      const paid = monthRecords.filter(r => r.statusBayar === 'SUDAH BAYAR').length;
      const unpaid = total - paid;
      const rate = total > 0 ? Math.round((paid / total) * 100) : 0;

      const r2 = monthRecords.filter(r => r.roda === 'R2').length;
      const r3 = monthRecords.filter(r => r.roda === 'R3').length;
      const r4 = monthRecords.filter(r => r.roda === 'R4').length;

      return {
        monthIndex: index + 1,
        monthName: name,
        total,
        paid,
        unpaid,
        rate,
        r2,
        r3,
        r4,
      };
    });
  }, [records, selectedYear]);

  // Annual Totals
  const annualTotal = records.length;
  const annualPaid = records.filter(r => r.statusBayar === 'SUDAH BAYAR').length;
  const annualUnpaid = annualTotal - annualPaid;
  const annualRate = annualTotal > 0 ? Math.round((annualPaid / annualTotal) * 100) : 0;

  return (
    <div className="space-y-6 pb-12">
      
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2.5">
              <img
                src="/logo_jabar_transparan.png"
                alt="Logo Jawa Barat"
                className="w-5 h-6 object-contain"
              />
              <span className="px-2 py-0.5 text-xs font-bold rounded bg-emerald-500 text-slate-950 uppercase font-mono">
                Laporan &amp; Rekapitulasi
              </span>
              <span className="text-xs text-amber-300 font-semibold whitespace-nowrap">
                Pusat Pengelolaan Pendapatan Daerah Wilayah Kota Cirebon
              </span>
            </div>
            <h1 className="text-xl font-bold text-white tracking-tight">
              Rekapitulasi Harian, Bulanan &amp; Laporan Tahunan
            </h1>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              Penyajian agregat data pendaftaran berkas kendaraan baru secara komprehensif 
              untuk kebutuhan pelaporan Bapenda Provinsi Jawa Barat, evaluasi penerimaan pajak BBNKB, 
              dan audit fisik arsip.
            </p>
          </div>

          {/* Export / Print Actions */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => exportToCSV(records, `REKAP_${reportTab.toUpperCase()}_CIREBON`)}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700 transition-colors flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5 text-blue-400" />
              <span>Export CSV</span>
            </button>

            <button
              onClick={() => exportToExcel(records, `REKAP_EXCEL_${reportTab.toUpperCase()}`)}
              className="px-3 py-2 bg-emerald-800/80 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors flex items-center gap-1.5"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-300" />
              <span>Export Excel</span>
            </button>

            <button
              onClick={onPrintPreview}
              className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold rounded-lg shadow-md transition-colors flex items-center gap-1.5 active:scale-95"
            >
              <Printer className="w-4 h-4 text-slate-950" />
              <span>Cetak Laporan Resmi</span>
            </button>
          </div>
        </div>

        {/* Tab Segment Controls */}
        <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
          <button
            onClick={() => setReportTab('daily')}
            className={`px-4 py-2 text-xs font-bold rounded-lg transition-all ${
              reportTab === 'daily'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Rekap Harian (Daily Ledger)
          </button>

          <button
            onClick={() => setReportTab('monthly')}
            className={`px-4 py-2 text-xs font-bold rounded-lg transition-all ${
              reportTab === 'monthly'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Rekap Bulanan (Januari - Desember)
          </button>

          <button
            onClick={() => setReportTab('annual')}
            className={`px-4 py-2 text-xs font-bold rounded-lg transition-all ${
              reportTab === 'annual'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Laporan Eksekutif Tahunan
          </button>
        </div>
      </div>

      {/* ANNUAL KPI SUMMARY */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">Total Akumulasi Arsip KBM</div>
          <div className="text-2xl font-bold font-mono text-white mt-1 tabular-nums">
            {annualTotal} Berkas
          </div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">Realisasi Lunas BBNKB/PKB</div>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1 tabular-nums">
            {annualPaid} Unit ({annualRate}%)
          </div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">Total Tertunda / Belum Bayar</div>
          <div className="text-2xl font-bold font-mono text-red-400 mt-1 tabular-nums">
            {annualUnpaid} Unit
          </div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">Tahun Anggaran</div>
          <div className="text-2xl font-bold font-mono text-amber-400 mt-1 tabular-nums">
            T.A. {selectedYear}
          </div>
        </div>
      </div>

      {/* TAB 1: REKAP BULANAN */}
      {reportTab === 'monthly' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm space-y-4 p-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                Rekapitulasi Bulanan KBM Baru Tahun {selectedYear}
              </h2>
              <p className="text-xs text-slate-400">
                Data agregat volume pendaftaran per bulan beserta rasio kepatuhan bayar dan jenis roda
              </p>
            </div>
            <span className="text-xs text-slate-400 font-mono">12 Bulan Kalender</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 uppercase font-semibold font-mono text-[11px] border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-4">Bulan</th>
                  <th className="py-2.5 px-4 text-center">Total KBM</th>
                  <th className="py-2.5 px-4 text-center">Sudah Bayar</th>
                  <th className="py-2.5 px-4 text-center">Belum Bayar</th>
                  <th className="py-2.5 px-4 text-center">Roda 2 (Motor)</th>
                  <th className="py-2.5 px-4 text-center">Roda 3</th>
                  <th className="py-2.5 px-4 text-center">Roda 4 (Mobil)</th>
                  <th className="py-2.5 px-4 text-right">Tingkat Pelunasan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 bg-slate-900/40">
                {monthlyRecap.map((m) => (
                  <tr key={m.monthIndex} className="hover:bg-slate-850/50 transition-colors">
                    <td className="py-2.5 px-4 font-semibold text-white flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5 text-blue-400" />
                      <span>{m.monthName} {selectedYear}</span>
                    </td>
                    <td className="py-2.5 px-4 text-center font-mono font-bold text-white tabular-nums">
                      {m.total > 0 ? `${m.total} unit` : '-'}
                    </td>
                    <td className="py-2.5 px-4 text-center font-mono text-emerald-400 font-semibold tabular-nums">
                      {m.paid > 0 ? `${m.paid} unit` : '-'}
                    </td>
                    <td className="py-2.5 px-4 text-center font-mono text-red-400 font-semibold tabular-nums">
                      {m.unpaid > 0 ? `${m.unpaid} unit` : '-'}
                    </td>
                    <td className="py-2.5 px-4 text-center font-mono text-slate-300 tabular-nums">
                      {m.r2 || '-'}
                    </td>
                    <td className="py-2.5 px-4 text-center font-mono text-slate-300 tabular-nums">
                      {m.r3 || '-'}
                    </td>
                    <td className="py-2.5 px-4 text-center font-mono text-slate-300 tabular-nums">
                      {m.r4 || '-'}
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono font-bold text-amber-400 tabular-nums">
                      {m.total > 0 ? `${m.rate}%` : '-'}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-slate-950 font-mono font-bold text-white border-t-2 border-slate-700">
                <tr>
                  <td className="py-3 px-4">TOTAL TAHUNAN</td>
                  <td className="py-3 px-4 text-center text-amber-400">{annualTotal} unit</td>
                  <td className="py-3 px-4 text-center text-emerald-400">{annualPaid} unit</td>
                  <td className="py-3 px-4 text-center text-red-400">{annualUnpaid} unit</td>
                  <td className="py-3 px-4 text-center">{records.filter(r => r.roda === 'R2').length}</td>
                  <td className="py-3 px-4 text-center">{records.filter(r => r.roda === 'R3').length}</td>
                  <td className="py-3 px-4 text-center">{records.filter(r => r.roda === 'R4').length}</td>
                  <td className="py-3 px-4 text-right text-amber-400">{annualRate}%</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: REKAP HARIAN (DAILY LEDGER) */}
      {reportTab === 'daily' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                Rekapitulasi Harian Pendaftaran KBM Baru
              </h2>
              <p className="text-xs text-slate-400">
                Rincian transaksi pendaftaran harian per jenis kendaraan dan transaksi
              </p>
            </div>
            <span className="text-xs text-slate-400 font-mono">{dailyRecap.length} Hari Aktif</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 uppercase font-semibold font-mono text-[11px] border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-4">Tanggal Entri</th>
                  <th className="py-2.5 px-3 text-center">Total Entri</th>
                  <th className="py-2.5 px-3 text-center text-emerald-400">Bayar</th>
                  <th className="py-2.5 px-3 text-center text-red-400">Belum Bayar</th>
                  <th className="py-2.5 px-3 text-center">R2</th>
                  <th className="py-2.5 px-3 text-center">R3</th>
                  <th className="py-2.5 px-3 text-center">R4</th>
                  <th className="py-2.5 px-3 text-center">CKD</th>
                  <th className="py-2.5 px-3 text-center">CBU</th>
                  <th className="py-2.5 px-3 text-center">GIIAS</th>
                  <th className="py-2.5 px-3 text-center">EX DUMP</th>
                  <th className="py-2.5 px-3 text-center">LISTRIK</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 bg-slate-900/40 font-mono">
                {dailyRecap.map((d) => (
                  <tr key={d.date} className="hover:bg-slate-850/50 transition-colors">
                    <td className="py-2.5 px-4 font-bold text-white flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5 text-blue-400" />
                      <span>{formatIndoDate(d.date)}</span>
                    </td>
                    <td className="py-2.5 px-3 text-center font-bold text-white">{d.total}</td>
                    <td className="py-2.5 px-3 text-center text-emerald-400 font-semibold">{d.paid}</td>
                    <td className="py-2.5 px-3 text-center text-red-400 font-semibold">{d.unpaid}</td>
                    <td className="py-2.5 px-3 text-center text-slate-400">{d.r2}</td>
                    <td className="py-2.5 px-3 text-center text-slate-400">{d.r3}</td>
                    <td className="py-2.5 px-3 text-center text-slate-400">{d.r4}</td>
                    <td className="py-2.5 px-3 text-center text-slate-400">{d.ckd}</td>
                    <td className="py-2.5 px-3 text-center text-slate-400">{d.cbu}</td>
                    <td className="py-2.5 px-3 text-center text-slate-400">{d.giias}</td>
                    <td className="py-2.5 px-3 text-center text-slate-400">{d.exdump}</td>
                    <td className="py-2.5 px-3 text-center text-slate-400">{d.ev}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: LAPORAN EKSEKUTIF TAHUNAN */}
      {reportTab === 'annual' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-6">
          <div className="border-b border-slate-800 pb-4 flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-white">
                Laporan Eksekutif Pengarsipan KBM Baru P3DW Kota Cirebon
              </h2>
              <p className="text-xs text-slate-400">
                Pusat Pengelolaan Pendapatan Daerah Wilayah Kota Cirebon · Bapenda Jabar
              </p>
            </div>
            <button
              onClick={onPrintPreview}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-lg flex items-center gap-2 shadow"
            >
              <Printer className="w-4 h-4" />
              <span>Pratinjau Format Cetak Resmi</span>
            </button>
          </div>

          <div className="space-y-4 text-xs leading-relaxed text-slate-300">
            <h3 className="text-sm font-semibold text-amber-400">I. Ringkasan Kinerja &amp; Pengarsipan</h3>
            <p>
              Pada tahun berjalan {selectedYear}, Pusat Pengelolaan Pendapatan Daerah Wilayah (P3DW) 
              Kota Cirebon telah mengarsipkan secara digital dan memverifikasi sebanyak 
              <strong className="text-white font-mono"> {annualTotal} berkas </strong> 
              faktur dan permohonan pendaftaran Kendaraan Bermotor Baru (KBM Baru).
            </p>
            <p>
              Tingkat kepatuhan penyelesaian pembayaran di loket mencapai 
              <strong className="text-emerald-400 font-mono"> {annualRate}% </strong> 
              ({annualPaid} unit lunas). Sisanya sebanyak 
              <strong className="text-red-400 font-mono"> {annualUnpaid} unit </strong> 
              tercatat dalam daftar kontrol penundaan pembayaran dengan dokumentasi alasan (reasoning) 
              lengkap yang meliputi verifikasi faktur ATPM, lelang dump, dan kelengkapan dokumen BPKB dealer.
            </p>

            <h3 className="text-sm font-semibold text-amber-400 pt-2">II. Rekomendasi Pengendalian Arsip</h3>
            <ul className="list-disc pl-5 space-y-1.5 text-slate-300">
              <li>
                Mempercepat rekonsiliasi harian dengan bank bjb terhadap berkas KBM yang belum melunasi pembayaran pada hari entri.
              </li>
              <li>
                Mengoptimalkan monitoring jatuh tempo faktur 30 hari kalender guna mencegah penumpukan denda administrasi keterlambatan BBNKB.
              </li>
              <li>
                Melakukan sinkronisasi rutin folder berkas digital pada komputer lokal (PC) dengan server arsip P3DW.
              </li>
            </ul>
          </div>
        </div>
      )}

    </div>
  );
};
