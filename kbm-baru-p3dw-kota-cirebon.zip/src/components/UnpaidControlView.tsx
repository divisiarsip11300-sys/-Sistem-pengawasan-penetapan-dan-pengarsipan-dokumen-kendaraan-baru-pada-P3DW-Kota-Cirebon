import React, { useState, useMemo } from 'react';
import { 
  CheckSquare, 
  Square, 
  ArrowRight, 
  AlertTriangle, 
  Clock, 
  CheckCircle2, 
  Search, 
  Calendar, 
  Folder, 
  FileText, 
  Edit3, 
  Save, 
  X,
  ExternalLink,
  Info,
  XCircle,
  RotateCcw,
  Trash2
} from 'lucide-react';
import { KbmRecord, RodaType, TransaksiType, PlatType, StatusBayar } from '../types/archive';
import { getTodayDateString, formatIndoDate, isOverdue, getPlatLabel, getRodaLabel, calculateJatuhTempo } from '../utils/formatters';

interface UnpaidControlViewProps {
  records: KbmRecord[];
  onUpdateRecord: (updated: KbmRecord) => void;
  onBatchPayToday: (ids: string[], noteAddendum: string) => void;
  onOpenEvident: (evidentUrl: string, title: string) => void;
}

export const UnpaidControlView: React.FC<UnpaidControlViewProps> = ({
  records,
  onUpdateRecord,
  onBatchPayToday,
  onOpenEvident,
}) => {
  const todayStr = getTodayDateString();

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterRoda, setFilterRoda] = useState<string>('ALL');
  const [filterTransaksi, setFilterTransaksi] = useState<string>('ALL');
  const [filterPlat, setFilterPlat] = useState<string>('ALL');
  const [filterStatusType, setFilterStatusType] = useState<'ALL' | 'BELUM_BAYAR' | 'DIBATALKAN'>('ALL');
  const [filterOverdueOnly, setFilterOverdueOnly] = useState<boolean>(false);

  // Selected IDs for batch checklist
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [batchModalOpen, setBatchModalOpen] = useState<boolean>(false);
  const [batchNote, setBatchNote] = useState<string>('Pelunasan loket kasir Samsat Kota Cirebon hari ini.');

  // Quick edit note state for single record
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [editingNoteText, setEditingNoteText] = useState<string>('');

  // Unpaid & Cancelled records (Semua kendaraan yang belum selesai bayar atau sempat dibatalkan)
  const unpaidAndCancelledList = useMemo(() => {
    return records.filter(r => r.statusBayar === 'BELUM BAYAR' || r.statusBayar === 'DIBATALKAN');
  }, [records]);

  // Counts
  const belumBayarCount = unpaidAndCancelledList.filter(r => r.statusBayar === 'BELUM BAYAR').length;
  const dibatalkanCount = unpaidAndCancelledList.filter(r => r.statusBayar === 'DIBATALKAN').length;

  // Filtered list
  const filteredList = useMemo(() => {
    return unpaidAndCancelledList.filter(r => {
      if (searchQuery) {
        const q = searchQuery.toLowerCase().trim();
        const match = r.nopol.toLowerCase().includes(q) ||
                      r.nama.toLowerCase().includes(q) ||
                      r.note.toLowerCase().includes(q) ||
                      r.linkFile.toLowerCase().includes(q);
        if (!match) return false;
      }
      if (filterStatusType === 'BELUM_BAYAR' && r.statusBayar !== 'BELUM BAYAR') return false;
      if (filterStatusType === 'DIBATALKAN' && r.statusBayar !== 'DIBATALKAN') return false;
      if (filterRoda !== 'ALL' && r.roda !== filterRoda) return false;
      if (filterTransaksi !== 'ALL' && r.transaksi !== filterTransaksi) return false;
      if (filterPlat !== 'ALL' && r.plat !== filterPlat) return false;
      if (filterOverdueOnly) {
        const dueInfo = isOverdue(r.jatemFakt, r.statusBayar);
        if (!dueInfo.isOverdue) return false;
      }
      return true;
    });
  }, [unpaidAndCancelledList, searchQuery, filterStatusType, filterRoda, filterTransaksi, filterPlat, filterOverdueOnly]);

  // Toggle selection
  const handleToggleSelect = (id: string) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const handleSelectAll = () => {
    if (selectedIds.length === filteredList.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredList.map(r => r.id));
    }
  };

  // Single record: Bayar Hari Ini & Pindahkan Data + Isi Ulang Jatem jika kosong
  const handleSinglePayToday = (record: KbmRecord) => {
    const isCancelledBefore = record.statusBayar === 'DIBATALKAN';
    const msg = isCancelledBefore
      ? `KBM ${record.nopol} sebelumnya BATAL BAYAR. Konfirmasi untuk MEMBAYAR HARI INI (${todayStr}) dan mengisi ulang tanggal jatuh tempo?`
      : `Pindahkan ${record.nopol} (${record.nama}) menjadi SUDAH BAYAR dengan Tanggal Bayar hari ini (${todayStr})?`;

    const confirmation = window.confirm(msg);
    if (!confirmation) return;

    // Refill jatemFakt if empty or if previously cancelled
    const refilledJatem = record.jatemFakt || calculateJatuhTempo(todayStr, record.rumusHari || 30);
    const addendum = isCancelledBefore
      ? `[Dipulihkan dari Batal Bayar & Dilunasi Hari Ini ${todayStr}]`
      : `[Dipindahkan & Dibayar pada ${todayStr}]`;

    const updated: KbmRecord = {
      ...record,
      statusBayar: 'SUDAH BAYAR',
      tglBayar: todayStr,
      jatemFakt: refilledJatem,
      note: record.note ? `${record.note} · ${addendum}` : addendum,
      updatedAt: new Date().toISOString(),
    };
    onUpdateRecord(updated);
  };

  // Single record: Batalkan Pembayaran & Hapus Tanggal Jatuh Tempo
  const handleSingleCancelAndClearJatem = (record: KbmRecord) => {
    const confirmation = window.confirm(
      `Tandai KBM ${record.nopol} sebagai DIBATALKAN (Batal Bayar)? Tanggal jatuh tempo akan DIHAPUS sesuai SOP pengawasan.`
    );
    if (!confirmation) return;

    const addendum = `[Batal Bayar & Jatuh Tempo Dihapus pada ${todayStr}]`;
    const updated: KbmRecord = {
      ...record,
      statusBayar: 'DIBATALKAN',
      tglBayar: '',
      jatemFakt: '', // Dihapus sesuai permintaan user!
      note: record.note ? `${record.note} · ${addendum}` : addendum,
      updatedAt: new Date().toISOString(),
    };
    onUpdateRecord(updated);
  };

  // Submit batch pay today
  const handleConfirmBatchPay = () => {
    if (selectedIds.length === 0) return;
    onBatchPayToday(selectedIds, batchNote);
    setSelectedIds([]);
    setBatchModalOpen(false);
  };

  // Save quick note edit
  const handleSaveNote = (record: KbmRecord) => {
    const updated: KbmRecord = {
      ...record,
      note: editingNoteText.trim(),
      updatedAt: new Date().toISOString(),
    };
    onUpdateRecord(updated);
    setEditingNoteId(null);
  };

  // Copy local folder link
  const handleCopyPath = (path: string) => {
    if (!path) return;
    navigator.clipboard.writeText(path);
    alert(`Alamat folder berkas disalin ke clipboard:\n${path}`);
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 text-xs font-bold rounded bg-amber-400 text-slate-950 uppercase font-mono">
                Tabel Kontrol Khusus
              </span>
              <span className="text-xs text-slate-400">P3DW Samsat Kota Cirebon</span>
            </div>
            <h1 className="text-xl font-bold text-white tracking-tight">
              Ceklis &amp; Pengendalian Kendaraan Belum Membayar / Batal Bayar
            </h1>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              Memantau berkas KBM baru yang belum melunasi atau sempat membatalkan pembayaran. 
              Jika wajib pajak <strong className="text-emerald-400">membayar hari ini</strong>, klik tombol 
              <strong className="text-amber-400"> "Bayar Hari Ini &amp; Isi Ulang Jatem"</strong> untuk otomatis memperbarui tanggal bayar ke hari ini, mengisi ulang jatuh tempo, dan memindahkan status menjadi lunas.
              Jika batal bayar, Anda dapat menghapus tanggal jatuh tempo dengan tombol <strong className="text-red-400">"Batal Bayar (Hapus Jatem)"</strong>.
            </p>
          </div>

          {/* Action Button: Batch Pay */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              disabled={selectedIds.length === 0}
              onClick={() => setBatchModalOpen(true)}
              className={`px-4 py-2.5 text-xs font-bold rounded-lg shadow transition-all flex items-center gap-2 ${
                selectedIds.length > 0
                  ? 'bg-amber-400 text-slate-950 hover:bg-amber-300 active:scale-95 cursor-pointer'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Bayar Hari Ini &amp; Pindahkan ({selectedIds.length})</span>
            </button>
          </div>
        </div>

        {/* Status Highlights */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-3 border-t border-slate-800 text-xs">
          <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800 flex items-center justify-between">
            <span className="text-slate-400">Total Tertunda/Batal:</span>
            <span className="font-mono font-bold text-amber-400 text-sm tabular-nums">
              {unpaidAndCancelledList.length} Unit
            </span>
          </div>
          <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800 flex items-center justify-between">
            <span className="text-slate-400">Belum Bayar:</span>
            <span className="font-mono font-bold text-yellow-400 text-sm tabular-nums">
              {belumBayarCount} Unit
            </span>
          </div>
          <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800 flex items-center justify-between">
            <span className="text-slate-400">Batal Bayar (Jatem Dihapus):</span>
            <span className="font-mono font-bold text-red-400 text-sm tabular-nums">
              {dibatalkanCount} Unit
            </span>
          </div>
          <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800 flex items-center justify-between">
            <span className="text-slate-400">Tanggal Bayar Hari Ini:</span>
            <span className="font-mono font-bold text-emerald-400 text-sm tabular-nums">
              {todayStr}
            </span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-6 gap-3">
          
          {/* Search Box */}
          <div className="md:col-span-2 relative">
            <input
              type="text"
              placeholder="Cari Nopol, Nama, Catatan reasoning..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-400 font-mono"
            />
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          </div>

          {/* Filter Status: Semua, Belum Bayar, Dibatalkan */}
          <div>
            <select
              value={filterStatusType}
              onChange={(e) => setFilterStatusType(e.target.value as 'ALL' | 'BELUM_BAYAR' | 'DIBATALKAN')}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-2 text-xs text-amber-300 font-medium focus:outline-none focus:border-amber-400"
            >
              <option value="ALL">Semua Status Tertunda ({unpaidAndCancelledList.length})</option>
              <option value="BELUM_BAYAR">Hanya Belum Bayar ({belumBayarCount})</option>
              <option value="DIBATALKAN">Hanya Batal Bayar ({dibatalkanCount})</option>
            </select>
          </div>

          {/* Filter Roda */}
          <div>
            <select
              value={filterRoda}
              onChange={(e) => setFilterRoda(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-2 text-xs text-slate-300 focus:outline-none focus:border-blue-500"
            >
              <option value="ALL">Semua Roda</option>
              <option value="R2">R2 (Motor)</option>
              <option value="R3">R3 (Tiga Roda)</option>
              <option value="R4">R4 (Mobil)</option>
            </select>
          </div>

          {/* Filter Transaksi */}
          <div>
            <select
              value={filterTransaksi}
              onChange={(e) => setFilterTransaksi(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-2 text-xs text-slate-300 focus:outline-none focus:border-blue-500"
            >
              <option value="ALL">Semua Transaksi</option>
              <option value="CKD">CKD</option>
              <option value="CBU">CBU</option>
              <option value="GIIAS">GIIAS</option>
              <option value="EX DUMP">EX DUMP</option>
              <option value="LISTRIK/HYB">LISTRIK/HYB</option>
            </select>
          </div>

          {/* Filter Plat */}
          <div>
            <select
              value={filterPlat}
              onChange={(e) => setFilterPlat(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-2 text-xs text-slate-300 focus:outline-none focus:border-blue-500"
            >
              <option value="ALL">Semua Plat</option>
              <option value="1">Plat 1 (Pribadi)</option>
              <option value="2">Plat 2 (Kuning)</option>
              <option value="3">Plat 3 (Merah)</option>
            </select>
          </div>

        </div>

        {/* Toggle Overdue Only Filter */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
          <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
            <input
              type="checkbox"
              checked={filterOverdueOnly}
              onChange={(e) => setFilterOverdueOnly(e.target.checked)}
              className="rounded bg-slate-950 border-slate-700 text-red-500 focus:ring-0"
            />
            <span className="text-red-400 font-medium">Hanya tampilkan yang lewat jatuh tempo faktur (Overdue)</span>
          </label>

          <span className="text-slate-400 font-mono text-[11px]">
            Menampilkan {filteredList.length} dari {unpaidAndCancelledList.length} unit terpantau
          </span>
        </div>
      </div>

      {/* Main Checklist Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase font-semibold font-mono text-[11px] border-b border-slate-800">
              <tr>
                <th className="py-3 px-4 w-10 text-center">
                  <button
                    onClick={handleSelectAll}
                    title="Pilih Semua"
                    className="text-slate-400 hover:text-white"
                  >
                    {selectedIds.length > 0 && selectedIds.length === filteredList.length ? (
                      <CheckSquare className="w-4 h-4 text-amber-400" />
                    ) : (
                      <Square className="w-4 h-4" />
                    )}
                  </button>
                </th>
                <th className="py-3 px-4">NOPOL &amp; Nama Pemilik</th>
                <th className="py-3 px-3">Status Kontrol</th>
                <th className="py-3 px-4">TGL Entri / Faktur</th>
                <th className="py-3 px-4">JATEM FAKT</th>
                <th className="py-3 px-4 text-center">Klasifikasi</th>
                <th className="py-3 px-4">Link Folder / Evident</th>
                <th className="py-3 px-4 min-w-[200px]">Note / Reasoning Petugas</th>
                <th className="py-3 px-4 text-right">Aksi Update &amp; Jatem</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 bg-slate-900/40">
              {filteredList.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-500 space-y-2">
                    <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto opacity-70" />
                    <p className="font-semibold text-slate-400">Tidak ada kendaraan dalam daftar kontrol.</p>
                    <p className="text-[11px]">Semua berkas KBM baru telah lunas atau telah disaring filter.</p>
                  </td>
                </tr>
              ) : (
                filteredList.map((record) => {
                  const isSelected = selectedIds.includes(record.id);
                  const isCancelled = record.statusBayar === 'DIBATALKAN';
                  const dueInfo = isOverdue(record.jatemFakt, record.statusBayar);
                  const isEditingNote = editingNoteId === record.id;

                  return (
                    <tr
                      key={record.id}
                      className={`hover:bg-slate-850/60 transition-colors ${
                        isSelected ? 'bg-amber-950/20' : ''
                      } ${isCancelled ? 'bg-red-950/10' : ''}`}
                    >
                      {/* Checkbox */}
                      <td className="py-3 px-4 text-center">
                        <button
                          onClick={() => handleToggleSelect(record.id)}
                          className="text-slate-400 hover:text-amber-400 cursor-pointer"
                        >
                          {isSelected ? (
                            <CheckSquare className="w-4 h-4 text-amber-400" />
                          ) : (
                            <Square className="w-4 h-4" />
                          )}
                        </button>
                      </td>

                      {/* NOPOL & Nama */}
                      <td className="py-3 px-4">
                        <div className="font-mono font-bold text-amber-300 text-sm tracking-wide">
                          {record.nopol}
                        </div>
                        <div className="text-[11px] text-slate-300 truncate max-w-[180px] font-medium">
                          {record.nama}
                        </div>
                      </td>

                      {/* Status Kontrol Badge */}
                      <td className="py-3 px-3">
                        {isCancelled ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-red-950 text-red-300 border border-red-800 font-mono">
                            <XCircle className="w-3 h-3 text-red-400" />
                            DIBATALKAN
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950/80 text-amber-300 border border-amber-800 font-mono">
                            <Clock className="w-3 h-3 text-amber-400" />
                            BELUM BAYAR
                          </span>
                        )}
                      </td>

                      {/* TGL Entri & Faktur */}
                      <td className="py-3 px-4 font-mono text-xs">
                        <div className="text-slate-200">
                          <span className="text-[10px] text-slate-500">Entri: </span>
                          {record.tgl}
                        </div>
                        <div className="text-slate-400 text-[11px]">
                          <span className="text-[10px] text-slate-500">Fakt: </span>
                          {record.tglFaktur}
                        </div>
                      </td>

                      {/* JATEM FAKT (Rumus / Dihapus jika Batal Bayar) */}
                      <td className="py-3 px-4">
                        {record.jatemFakt ? (
                          <div>
                            <div className="font-mono font-semibold text-slate-200">
                              {record.jatemFakt}
                            </div>
                            {dueInfo.isOverdue ? (
                              <span className="text-[10px] text-red-400 font-semibold flex items-center gap-1">
                                <AlertTriangle className="w-3 h-3" />
                                Terlambat {Math.abs(dueInfo.daysRemaining)} hari
                              </span>
                            ) : (
                              <span className="text-[10px] text-amber-400/90 font-mono">
                                {dueInfo.daysRemaining} hari tersisa
                              </span>
                            )}
                          </div>
                        ) : (
                          <div className="text-red-400 font-mono text-[11px] font-semibold flex items-center gap-1">
                            <Trash2 className="w-3 h-3" />
                            <span>Jatem Dihapus (Batal)</span>
                          </div>
                        )}
                      </td>

                      {/* Klasifikasi */}
                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-1 font-mono text-[11px]">
                          <span className="px-1.5 py-0.5 rounded bg-blue-900/60 border border-blue-700/60 text-blue-200 font-semibold">
                            {record.roda}
                          </span>
                          <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                            {record.transaksi}
                          </span>
                          <span className="px-1.5 py-0.5 rounded bg-amber-900/50 border border-amber-700/60 text-amber-300 font-semibold">
                            P{record.plat}
                          </span>
                        </div>
                      </td>

                      {/* Link Folder PC & Evident */}
                      <td className="py-3 px-4">
                        <div className="space-y-1">
                          {record.linkFile ? (
                            <button
                              type="button"
                              onClick={() => handleCopyPath(record.linkFile)}
                              title="Klik untuk salin alamat folder PC"
                              className="text-[11px] text-amber-300 hover:text-amber-200 font-mono flex items-center gap-1 underline underline-offset-2 truncate max-w-[160px]"
                            >
                              <Folder className="w-3.5 h-3.5 shrink-0" />
                              <span className="truncate">{record.linkFile}</span>
                            </button>
                          ) : (
                            <span className="text-[10px] text-slate-500 italic">Belum ada link PC</span>
                          )}

                          {record.evident && (
                            <button
                              type="button"
                              onClick={() => onOpenEvident(record.evident, `Arsip Evident ${record.nopol}`)}
                              className="text-[10px] text-blue-400 hover:text-blue-300 flex items-center gap-1 font-medium"
                            >
                              <ExternalLink className="w-3 h-3" /> Lihat Foto Arsip
                            </button>
                          )}
                        </div>
                      </td>

                      {/* Note / Reasoning Petugas (Direct Edit Available) */}
                      <td className="py-3 px-4">
                        {isEditingNote ? (
                          <div className="space-y-1.5">
                            <input
                              type="text"
                              value={editingNoteText}
                              onChange={(e) => setEditingNoteText(e.target.value)}
                              className="w-full bg-slate-950 border border-amber-400 rounded px-2 py-1 text-xs text-white"
                              autoFocus
                            />
                            <div className="flex gap-1.5">
                              <button
                                onClick={() => handleSaveNote(record)}
                                className="px-2 py-0.5 bg-amber-400 text-slate-950 text-[10px] font-bold rounded flex items-center gap-1 cursor-pointer"
                              >
                                <Save className="w-3 h-3" /> Simpan
                              </button>
                              <button
                                onClick={() => setEditingNoteId(null)}
                                className="px-2 py-0.5 bg-slate-800 text-slate-300 text-[10px] rounded cursor-pointer"
                              >
                                Batal
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div 
                            onClick={() => {
                              setEditingNoteId(record.id);
                              setEditingNoteText(record.note || '');
                            }}
                            className="group cursor-pointer p-1 rounded hover:bg-slate-800/80 transition-colors"
                            title="Klik untuk ubah reasoning catatan"
                          >
                            <p className="text-[11px] text-slate-300 italic line-clamp-2">
                              {record.note ? `"${record.note}"` : <span className="text-slate-500 not-italic">+ Tambah alasan / reasoning</span>}
                            </p>
                            <span className="text-[10px] text-slate-500 group-hover:text-amber-400 flex items-center gap-1 mt-0.5">
                              <Edit3 className="w-2.5 h-2.5" /> Edit Reasoning
                            </span>
                          </div>
                        )}
                      </td>

                      {/* Action: Bayar Hari Ini & Isi Ulang Jatem vs Batal Bayar & Hapus Jatem */}
                      <td className="py-3 px-4 text-right">
                        <div className="flex flex-col items-end gap-1.5">
                          {/* Tombol Utama: Bayar Hari Ini */}
                          <button
                            onClick={() => handleSinglePayToday(record)}
                            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold text-xs rounded-lg shadow-sm transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                            title="Lunasi hari ini, update tanggal bayar ke hari ini dan isi ulang jatuh tempo"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>{isCancelled ? 'Bayar Hari Ini & Isi Jatem' : 'Bayar Hari Ini'}</span>
                          </button>

                          {/* Tombol Batalkan Pembayaran (Hanya jika belum batal) */}
                          {!isCancelled && (
                            <button
                              onClick={() => handleSingleCancelAndClearJatem(record)}
                              className="px-2.5 py-1 bg-red-950/60 hover:bg-red-900/80 text-red-300 border border-red-800/60 text-[10px] font-medium rounded transition-colors flex items-center gap-1 cursor-pointer"
                              title="Tandai batal bayar dan hapus tanggal jatuh tempo"
                            >
                              <Trash2 className="w-3 h-3 text-red-400" />
                              <span>Batal Bayar (Hapus Jatem)</span>
                            </button>
                          )}
                        </div>
                      </td>

                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Batch Payment Modal */}
      {batchModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 rounded-xl p-6 max-w-md w-full space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                Konfirmasi Pembayaran Kolektif Hari Ini
              </h3>
              <button
                onClick={() => setBatchModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Anda akan memindahkan <strong className="text-amber-400 font-mono">{selectedIds.length} kendaraan</strong> terpilih menjadi berstatus <strong className="text-emerald-400">SUDAH BAYAR</strong> dengan Tanggal Bayar diset ke <strong className="text-white font-mono">{todayStr} (Hari Ini)</strong> dan tanggal jatuh tempo yang sebelumnya dihapus akan otomatis <strong className="text-amber-300">diisi ulang</strong>.
            </p>

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-300">
                Catatan Tambahan / Keterangan Kasir:
              </label>
              <textarea
                rows={2}
                value={batchNote}
                onChange={(e) => setBatchNote(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-amber-400"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setBatchModalOpen(false)}
                className="px-3 py-1.5 text-xs text-slate-300 hover:text-white rounded"
              >
                Batal
              </button>
              <button
                onClick={handleConfirmBatchPay}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg shadow active:scale-95 transition-all cursor-pointer"
              >
                Proses {selectedIds.length} Kendaraan
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
