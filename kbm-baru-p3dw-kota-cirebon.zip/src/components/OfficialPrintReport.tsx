import React from 'react';
import { X, Printer } from 'lucide-react';
import { KbmRecord } from '../types/archive';
import { formatIndoDate, getPlatLabel, getTodayDateString } from '../utils/formatters';

interface OfficialPrintReportProps {
  records: KbmRecord[];
  onClose: () => void;
}

export const OfficialPrintReport: React.FC<OfficialPrintReportProps> = ({
  records,
  onClose,
}) => {
  const todayStr = getTodayDateString();
  const paidCount = records.filter(r => r.statusBayar === 'SUDAH BAYAR').length;
  const unpaidCount = records.filter(r => r.statusBayar === 'BELUM BAYAR').length;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-sm p-4 sm:p-6 flex justify-center">
      <div className="bg-white text-slate-900 rounded-xl shadow-2xl max-w-5xl w-full p-8 print:p-0 print:shadow-none print:w-full space-y-6">
        
        {/* Screen Toolbar (Hidden on print) */}
        <div className="no-print flex items-center justify-between pb-4 border-b border-slate-200">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Format Cetak Laporan Resmi P3DW Kota Cirebon
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-lg shadow flex items-center gap-2 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Cetak Sekarang (Print / PDF)</span>
            </button>
            <button
              onClick={onClose}
              className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-lg flex items-center gap-1.5"
            >
              <X className="w-4 h-4" />
              <span>Tutup</span>
            </button>
          </div>
        </div>

        {/* OFFICIAL KOP SURAT P3DW KOTA CIREBON */}
        <div className="border-b-4 border-double border-slate-900 pb-4 text-center relative flex items-center justify-between gap-4 px-2">
          <div className="w-20 h-24 shrink-0 flex items-center justify-center">
            <img
              src="/logo_jabar_transparan.png"
              alt="Lambang Daerah Provinsi Jawa Barat"
              className="w-full h-full object-contain"
            />
          </div>
          <div className="text-center flex-1">
            <h3 className="text-xs sm:text-sm font-bold uppercase tracking-widest text-slate-800 whitespace-nowrap">
              Pemerintah Daerah Provinsi Jawa Barat
            </h3>
            <h2 className="text-sm sm:text-base font-extrabold uppercase tracking-wider text-slate-900 whitespace-nowrap">
              Badan Pendapatan Daerah
            </h2>
            <h1 className="text-sm sm:text-base md:text-[18px] lg:text-[19px] font-black uppercase text-slate-950 tracking-tight whitespace-nowrap">
              Pusat Pengelolaan Pendapatan Daerah Wilayah Kota Cirebon
            </h1>
            <p className="text-[11px] text-slate-600 mt-1 whitespace-nowrap">
              Jl. Pemuda No. 44, Kel. Sunyaragi, Kec. Kesambi, Kota Cirebon 45132 · Telp. (0231) 203874
            </p>
          </div>
          <div className="w-20 h-24 shrink-0 hidden sm:block" aria-hidden="true" />
        </div>

        {/* Title */}
        <div className="text-center space-y-1">
          <h2 className="text-sm font-extrabold uppercase tracking-wider underline">
            Laporan Rekapitulasi Pengarsipan Kendaraan Bermotor Baru (KBM Baru)
          </h2>
          <p className="text-xs text-slate-600">
            Nomor: 973 / ARSIP-KBM / P3DW-CRB / {new Date().getFullYear()}
          </p>
        </div>

        {/* Meta info */}
        <div className="flex justify-between text-xs text-slate-700 font-mono py-1 border-y border-slate-300">
          <div>
            Tanggal Laporan: <strong>{formatIndoDate(todayStr)}</strong>
          </div>
          <div>
            Total Berkas: <strong>{records.length} Unit</strong> (Lunas: {paidCount} | Tertunda: {unpaidCount})
          </div>
        </div>

        {/* Table for Print */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border border-slate-900 border-collapse">
            <thead>
              <tr className="bg-slate-100 border-b border-slate-900 text-slate-900 font-bold font-mono text-[11px]">
                <th className="py-2 px-2 border-r border-slate-900 text-center w-8">No</th>
                <th className="py-2 px-2 border-r border-slate-900">TGL Entri</th>
                <th className="py-2 px-2 border-r border-slate-900">NOPOL</th>
                <th className="py-2 px-2 border-r border-slate-900">Nama Pemilik</th>
                <th className="py-2 px-2 border-r border-slate-900">Tgl Faktur</th>
                <th className="py-2 px-2 border-r border-slate-900">Jatem Faktur</th>
                <th className="py-2 px-2 border-r border-slate-900">Tgl Bayar</th>
                <th className="py-2 px-1 border-r border-slate-900 text-center">Roda</th>
                <th className="py-2 px-2 border-r border-slate-900 text-center">Transaksi</th>
                <th className="py-2 px-1 border-r border-slate-900 text-center">Plat</th>
                <th className="py-2 px-2 border-r border-slate-900 text-center">Status</th>
                <th className="py-2 px-2">Catatan / Reasoning</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-400 font-sans">
              {records.map((r, i) => (
                <tr key={r.id} className="text-[11px]">
                  <td className="py-1.5 px-2 border-r border-slate-900 text-center font-mono">{i + 1}</td>
                  <td className="py-1.5 px-2 border-r border-slate-900 font-mono">{r.tgl}</td>
                  <td className="py-1.5 px-2 border-r border-slate-900 font-mono font-bold text-slate-950">{r.nopol}</td>
                  <td className="py-1.5 px-2 border-r border-slate-900 uppercase font-medium">{r.nama}</td>
                  <td className="py-1.5 px-2 border-r border-slate-900 font-mono">{r.tglFaktur}</td>
                  <td className="py-1.5 px-2 border-r border-slate-900 font-mono">{r.jatemFakt}</td>
                  <td className="py-1.5 px-2 border-r border-slate-900 font-mono">{r.tglBayar || '-'}</td>
                  <td className="py-1.5 px-1 border-r border-slate-900 text-center font-mono">{r.roda}</td>
                  <td className="py-1.5 px-2 border-r border-slate-900 text-center font-mono">{r.transaksi}</td>
                  <td className="py-1.5 px-1 border-r border-slate-900 text-center font-mono">{r.plat}</td>
                  <td className="py-1.5 px-2 border-r border-slate-900 text-center font-bold">
                    {r.statusBayar === 'SUDAH BAYAR' ? 'LUNAS' : 'TERTUNDA'}
                  </td>
                  <td className="py-1.5 px-2 italic text-slate-700 text-[10px]">
                    {r.note || '-'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Signature Block */}
        <div className="pt-8 grid grid-cols-2 text-xs">
          <div>
            <p>Mengetahui,</p>
            <p className="font-bold">Kepala Seksi Pendataan dan Penetapan</p>
            <div className="h-16" />
            <p className="font-bold underline">H. DEDI KURNIAWAN, S.Sos., M.Si.</p>
            <p className="text-slate-600 font-mono">NIP. 19780512 200501 1 008</p>
          </div>
          <div className="text-right">
            <p>Kota Cirebon, {formatIndoDate(todayStr)}</p>
            <p className="font-bold">Petugas Pengarsipan KBM Baru,</p>
            <div className="h-16" />
            <p className="font-bold underline">TIM VERIFIKATOR P3DW CIREBON</p>
            <p className="text-slate-600 font-mono">Loket Pelayanan KBM Baru Samsat</p>
          </div>
        </div>

      </div>
    </div>
  );
};
