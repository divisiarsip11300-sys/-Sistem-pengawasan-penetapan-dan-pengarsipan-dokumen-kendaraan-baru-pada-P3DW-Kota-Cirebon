import React from 'react';
import { Plus, LayoutDashboard, FileText, CheckSquare, BarChart3, Database } from 'lucide-react';

interface NavbarProps {
  activeTab: 'dashboard' | 'archive' | 'unpaid' | 'reports';
  setActiveTab: (tab: 'dashboard' | 'archive' | 'unpaid' | 'reports') => void;
  onOpenNewModal: () => void;
  unpaidCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenNewModal,
  unpaidCount
}) => {
  return (
    <header className="no-print sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-6 h-16">
          
          {/* Zone 1: Single text element wordmark + Insignia */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-9 h-11 shrink-0 flex items-center justify-center">
              <img
                src="/logo_jabar_transparan.png"
                alt="Lambang Jawa Barat P3DW Kota Cirebon"
                className="w-full h-full object-contain drop-shadow"
              />
            </div>
            <div className="flex flex-col">
              <span className="text-sm sm:text-base font-extrabold tracking-tight text-white whitespace-nowrap">
                KENDARAAN BERMOTOR BARU
              </span>
              <span className="text-[10px] sm:text-[11px] font-semibold text-amber-300 tracking-wide uppercase whitespace-nowrap">
                Pusat Pengelolaan Pendapatan Daerah Wilayah Kota Cirebon
              </span>
            </div>
          </div>

          {/* Zone 2: Navigation Links (Single-line, clear interactive states) */}
          <nav className="hidden md:flex items-center gap-1 text-sm font-medium">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'dashboard'
                  ? 'bg-blue-600 text-white font-semibold shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <LayoutDashboard className="w-4 h-4 text-amber-300" />
              <span>Dashboard &amp; Statistik</span>
            </button>

            <button
              onClick={() => setActiveTab('archive')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'archive'
                  ? 'bg-blue-600 text-white font-semibold shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Database className="w-4 h-4 text-blue-300" />
              <span>Semua Arsip KBM</span>
            </button>

            <button
              onClick={() => setActiveTab('unpaid')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'unpaid'
                  ? 'bg-amber-500 text-slate-950 font-semibold shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <CheckSquare className="w-4 h-4 text-amber-400" />
              <span>Kontrol Belum Bayar</span>
              {unpaidCount > 0 && (
                <span className="ml-1 px-1.5 py-0.2 text-[11px] font-bold rounded bg-amber-400/20 text-amber-300 border border-amber-400/40">
                  {unpaidCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('reports')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'reports'
                  ? 'bg-blue-600 text-white font-semibold shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <BarChart3 className="w-4 h-4 text-emerald-400" />
              <span>Rekap Harian &amp; Tahunan</span>
            </button>
          </nav>

          {/* Zone 3: 1 Primary Action */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenNewModal}
              className="flex items-center gap-2 px-4 py-2 text-sm font-semibold text-slate-950 bg-gradient-to-r from-amber-400 to-amber-300 hover:from-amber-300 hover:to-amber-200 rounded-lg shadow transition-all duration-150 whitespace-nowrap shrink-0 cursor-pointer active:scale-95"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>+ Entri Arsip Baru</span>
            </button>
          </div>

        </div>

        {/* Mobile secondary tab strip */}
        <div className="md:hidden flex items-center justify-around py-2 border-t border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`py-1 px-2 rounded ${activeTab === 'dashboard' ? 'text-amber-400 font-bold' : 'text-slate-400'}`}
          >
            Dashboard
          </button>
          <button
            onClick={() => setActiveTab('archive')}
            className={`py-1 px-2 rounded ${activeTab === 'archive' ? 'text-amber-400 font-bold' : 'text-slate-400'}`}
          >
            Arsip KBM
          </button>
          <button
            onClick={() => setActiveTab('unpaid')}
            className={`py-1 px-2 rounded ${activeTab === 'unpaid' ? 'text-amber-400 font-bold' : 'text-slate-400'}`}
          >
            Belum Bayar ({unpaidCount})
          </button>
          <button
            onClick={() => setActiveTab('reports')}
            className={`py-1 px-2 rounded ${activeTab === 'reports' ? 'text-amber-400 font-bold' : 'text-slate-400'}`}
          >
            Rekap
          </button>
        </div>
      </div>
    </header>
  );
};
