export type RodaType = 'R2' | 'R3' | 'R4';

export type TransaksiType = 'CKD' | 'CBU' | 'GIIAS' | 'EX DUMP' | 'LISTRIK/HYB';

export type PlatType = '1' | '2' | '3'; // 1: Hitam/Putih (Pribadi), 2: Kuning (Umum), 3: Merah (Pemerintah)

export type StatusBayar = 'SUDAH BAYAR' | 'BELUM BAYAR' | 'DIBATALKAN';

export interface KbmRecord {
  id: string;
  tgl: string; // Tanggal Entri (YYYY-MM-DD)
  nopol: string; // Nomor Polisi (e.g. E 2841 ABC)
  nama: string; // Nama Pemilik / Wajib Pajak
  tglFaktur: string; // Tanggal Faktur (YYYY-MM-DD)
  tglBayar: string; // Tanggal Bayar (YYYY-MM-DD, default today if paid)
  jatemFakt: string; // Jatuh Tempo Faktur (Rumus: Tgl Faktur + interval hari)
  rumusHari: number; // Interval hari rumus (default 30)
  roda: RodaType; // R2, R3, R4
  transaksi: TransaksiType; // CKD, CBU, GIIAS, EX DUMP, LISTRIK/HYB
  plat: PlatType; // 1, 2, 3
  statusBayar: StatusBayar;
  evident: string; // Base64 data URL atau URL gambar evident
  evidentName?: string;
  linkFile: string; // Alamat link folder / file pada PC lokal (e.g. D:\ARSIP_SAMSAT\KBM_BARU\...)
  note: string; // Catatan & reasoning petugas (alasan penundaan, dealer, kelengkapan, dll)
  createdAt: string;
  updatedAt: string;
}

export interface FilterState {
  searchQuery: string;
  tglEntriStart: string;
  tglEntriEnd: string;
  tglFakturStart: string;
  tglFakturEnd: string;
  tglBayarStart: string;
  tglBayarEnd: string;
  roda: string; // 'ALL' or RodaType
  transaksi: string; // 'ALL' or TransaksiType
  plat: string; // 'ALL' or PlatType
  statusBayar: string; // 'ALL' or StatusBayar
}

export interface OperationalNarrative {
  totalRegistered: number;
  totalPaid: number;
  totalUnpaid: number;
  paidPercentage: number;
  unpaidPercentage: number;
  todayRegisteredCount: number;
  todayPaidCount: number;
  commonReasons: { reason: string; count: number }[];
  summaryText: string;
  recommendations: string[];
}
