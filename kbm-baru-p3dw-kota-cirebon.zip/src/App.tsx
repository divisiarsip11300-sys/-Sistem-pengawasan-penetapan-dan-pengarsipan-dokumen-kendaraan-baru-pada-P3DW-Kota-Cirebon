import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { ArchiveTableView } from './components/ArchiveTableView';
import { UnpaidControlView } from './components/UnpaidControlView';
import { ReportsView } from './components/ReportsView';
import { FormModal } from './components/FormModal';
import { EvidentModal } from './components/EvidentModal';
import { OfficialPrintReport } from './components/OfficialPrintReport';
import { KbmRecord } from './types/archive';
import { loadStoredRecords, saveStoredRecords, INITIAL_KBM_RECORDS } from './data/initialData';
import { getTodayDateString, calculateJatuhTempo } from './utils/formatters';
import { RotateCcw, ShieldCheck, MapPin, Phone, Building } from 'lucide-react';

export default function App() {
  const [records, setRecords] = useState<KbmRecord[]>(() => loadStoredRecords());
  const [activeTab, setActiveTab] = useState<'dashboard' | 'archive' | 'unpaid' | 'reports'>('dashboard');
  
  // Modal states
  const [isFormModalOpen, setIsFormModalOpen] = useState<boolean>(false);
  const [editingRecord, setEditingRecord] = useState<KbmRecord | null>(null);
  
  const [evidentModal, setEvidentModal] = useState<{
    isOpen: boolean;
    url: string;
    title: string;
  }>({
    isOpen: false,
    url: '',
    title: '',
  });

  const [isPrintReportOpen, setIsPrintReportOpen] = useState<boolean>(false);

  // Sync to local storage
  useEffect(() => {
    saveStoredRecords(records);
  }, [records]);

  // Unpaid count for navbar badge (termasuk yang dibatalkan / belum bayar)
  const unpaidCount = records.filter(r => r.statusBayar === 'BELUM BAYAR' || r.statusBayar === 'DIBATALKAN').length;

  // Handlers
  const handleOpenNewModal = () => {
    setEditingRecord(null);
    setIsFormModalOpen(true);
  };

  const handleEditRecord = (record: KbmRecord) => {
    setEditingRecord(record);
    setIsFormModalOpen(true);
  };

  const handleSaveRecord = (record: KbmRecord) => {
    setRecords(prev => {
      const exists = prev.some(r => r.id === record.id);
      if (exists) {
        return prev.map(r => (r.id === record.id ? record : r));
      }
      return [record, ...prev];
    });
  };

  const handleUpdateRecord = (updated: KbmRecord) => {
    setRecords(prev => prev.map(r => (r.id === updated.id ? updated : r)));
  };

  const handleDeleteRecord = (id: string) => {
    setRecords(prev => prev.filter(r => r.id !== id));
  };

  // Batch action from Unpaid Control view: Pay Today & Migrate
  const handleBatchPayToday = (ids: string[], noteAddendum: string) => {
    const today = getTodayDateString();
    setRecords(prev =>
      prev.map(r => {
        if (ids.includes(r.id)) {
          const newNote = r.note
            ? `${r.note} · [Dipindahkan & Dibayar ${today}: ${noteAddendum}]`
            : `[Dipindahkan & Dibayar ${today}: ${noteAddendum}]`;
          const refilledJatem = r.jatemFakt || calculateJatuhTempo(today, r.rumusHari || 30);
          return {
            ...r,
            statusBayar: 'SUDAH BAYAR',
            tglBayar: today,
            jatemFakt: refilledJatem,
            note: newNote,
            updatedAt: new Date().toISOString(),
          };
        }
        return r;
      })
    );
  };

  // Open photo viewer
  const handleOpenEvident = (evidentUrl: string, title: string) => {
    setEvidentModal({
      isOpen: true,
      url: evidentUrl,
      title,
    });
  };

  // Reset to initial sample data
  const handleResetData = () => {
    if (window.confirm('Muat ulang data sampel default Samsat Kota Cirebon? Data perubahan lokal saat ini akan digantikan.')) {
      setRecords(INITIAL_KBM_RECORDS);
      saveStoredRecords(INITIAL_KBM_RECORDS);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      
      {/* Navigation Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenNewModal={handleOpenNewModal}
        unpaidCount={unpaidCount}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {activeTab === 'dashboard' && (
          <DashboardView
            records={records}
            onNavigateToUnpaid={() => setActiveTab('unpaid')}
            onNavigateToArchive={() => setActiveTab('archive')}
            onOpenNewModal={handleOpenNewModal}
          />
        )}

        {activeTab === 'archive' && (
          <ArchiveTableView
            records={records}
            onEditRecord={handleEditRecord}
            onUpdateRecord={handleUpdateRecord}
            onDeleteRecord={handleDeleteRecord}
            onOpenEvident={handleOpenEvident}
            onPrintPreview={() => setIsPrintReportOpen(true)}
          />
        )}

        {activeTab === 'unpaid' && (
          <UnpaidControlView
            records={records}
            onUpdateRecord={handleUpdateRecord}
            onBatchPayToday={handleBatchPayToday}
            onOpenEvident={handleOpenEvident}
          />
        )}

        {activeTab === 'reports' && (
          <ReportsView
            records={records}
            onPrintPreview={() => setIsPrintReportOpen(true)}
          />
        )}
      </main>

      {/* Modal Dialogs */}
      <FormModal
        isOpen={isFormModalOpen}
        onClose={() => setIsFormModalOpen(false)}
        onSave={handleSaveRecord}
        initialRecord={editingRecord}
      />

      <EvidentModal
        isOpen={evidentModal.isOpen}
        onClose={() => setEvidentModal({ isOpen: false, url: '', title: '' })}
        imageUrl={evidentModal.url}
        title={evidentModal.title}
      />

      {isPrintReportOpen && (
        <OfficialPrintReport
          records={records}
          onClose={() => setIsPrintReportOpen(false)}
        />
      )}

      {/* Footer */}
      <footer className="no-print mt-auto border-t border-slate-900 bg-slate-950/80 py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Building className="w-4 h-4 text-amber-400" />
            <span>
              <strong>KBM BARU P3DW KOTA CIREBON</strong> · Kantor Pelayanan Pajak Daerah &amp; Samsat Kota Cirebon
            </span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={handleResetData}
              className="hover:text-amber-400 flex items-center gap-1 transition-colors cursor-pointer"
              title="Kembalikan data ke awal mula contoh Samsat"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Data Contoh</span>
            </button>
            <span aria-hidden="true">·</span>
            <span>Bapenda Provinsi Jawa Barat</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
