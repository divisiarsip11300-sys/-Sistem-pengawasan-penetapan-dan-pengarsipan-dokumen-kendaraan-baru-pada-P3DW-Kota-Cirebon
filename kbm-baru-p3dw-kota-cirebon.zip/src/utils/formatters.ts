import { KbmRecord } from '../types/archive';

export function getTodayDateString(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function calculateJatuhTempo(tglFaktur: string, daysToAdd: number = 30): string {
  if (!tglFaktur) return '';
  try {
    const parts = tglFaktur.split('-');
    if (parts.length !== 3) return '';
    const date = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
    date.setDate(date.getDate() + daysToAdd);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  } catch {
    return '';
  }
}

export function isOverdue(jatemFakt: string, statusBayar: string): { isOverdue: boolean; daysRemaining: number } {
  if (statusBayar === 'SUDAH BAYAR' || !jatemFakt) {
    return { isOverdue: false, daysRemaining: 999 };
  }
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const parts = jatemFakt.split('-');
  if (parts.length !== 3) return { isOverdue: false, daysRemaining: 0 };
  const dueDate = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
  dueDate.setHours(0, 0, 0, 0);

  const diffTime = dueDate.getTime() - today.getTime();
  const daysRemaining = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return {
    isOverdue: daysRemaining < 0,
    daysRemaining,
  };
}

export function formatIndoDate(dateStr: string): string {
  if (!dateStr) return '-';
  const parts = dateStr.split('-');
  if (parts.length !== 3) return dateStr;
  const months = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];
  const day = parseInt(parts[2], 10);
  const monthIdx = parseInt(parts[1], 10) - 1;
  const year = parts[0];
  return `${day} ${months[monthIdx] || ''} ${year}`;
}

export function getPlatLabel(plat: string): string {
  switch (plat) {
    case '1':
      return 'Plat 1 (Pribadi)';
    case '2':
      return 'Plat 2 (Angkutan Umum)';
    case '3':
      return 'Plat 3 (Instansi / Dinas)';
    default:
      return `Plat ${plat}`;
  }
}

export function getRodaLabel(roda: string): string {
  switch (roda) {
    case 'R2':
      return 'R2 - Sepeda Motor';
    case 'R3':
      return 'R3 - Roda Tiga';
    case 'R4':
      return 'R4 - Roda Empat+';
    default:
      return roda;
  }
}

export function exportToCSV(records: KbmRecord[], filenamePrefix: string = 'KBM_BARU_P3DW_CIREBON'): void {
  const headers = [
    'No',
    'Tgl Entri',
    'No Polisi',
    'Nama Pemilik',
    'Tgl Faktur',
    'Tgl Bayar',
    'Jatem Faktur (Rumus)',
    'Roda',
    'Transaksi',
    'Plat',
    'Status Pembayaran',
    'Link File Folder PC',
    'Catatan / Reasoning Petugas'
  ];

  const rows = records.map((r, index) => [
    index + 1,
    `"${r.tgl || ''}"`,
    `"${r.nopol || ''}"`,
    `"${(r.nama || '').replace(/"/g, '""')}"`,
    `"${r.tglFaktur || ''}"`,
    `"${r.tglBayar || ''}"`,
    `"${r.jatemFakt || ''}"`,
    `"${r.roda || ''}"`,
    `"${r.transaksi || ''}"`,
    `"${getPlatLabel(r.plat)}"`,
    `"${r.statusBayar || ''}"`,
    `"${(r.linkFile || '').replace(/"/g, '""')}"`,
    `"${(r.note || '').replace(/"/g, '""')}"`
  ]);

  const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${filenamePrefix}_${getTodayDateString()}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function exportToExcel(records: KbmRecord[], filenamePrefix: string = 'LAPORAN_KBM_P3DW_CIREBON'): void {
  // Generates an HTML-based Excel spreadsheet file with proper table formatting
  const tableRows = records.map((r, index) => `
    <tr>
      <td style="text-align:center; border: 1px solid #d1d5db;">${index + 1}</td>
      <td style="text-align:center; border: 1px solid #d1d5db;">${r.tgl}</td>
      <td style="font-weight:bold; border: 1px solid #d1d5db;">${r.nopol}</td>
      <td style="border: 1px solid #d1d5db;">${r.nama}</td>
      <td style="text-align:center; border: 1px solid #d1d5db;">${r.tglFaktur}</td>
      <td style="text-align:center; border: 1px solid #d1d5db;">${r.tglBayar || '-'}</td>
      <td style="text-align:center; border: 1px solid #d1d5db;">${r.jatemFakt}</td>
      <td style="text-align:center; border: 1px solid #d1d5db;">${r.roda}</td>
      <td style="text-align:center; border: 1px solid #d1d5db;">${r.transaksi}</td>
      <td style="text-align:center; border: 1px solid #d1d5db;">Plat ${r.plat}</td>
      <td style="text-align:center; font-weight:bold; color: ${r.statusBayar === 'SUDAH BAYAR' ? '#166534' : '#991b1b'}; border: 1px solid #d1d5db;">
        ${r.statusBayar}
      </td>
      <td style="border: 1px solid #d1d5db;">${r.linkFile || '-'}</td>
      <td style="border: 1px solid #d1d5db;">${r.note || '-'}</td>
    </tr>
  `).join('');

  const excelHtml = `
    <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
      <head>
        <meta http-equiv="content-type" content="text/plain; charset=UTF-8"/>
        <!--[if gte mso 9]>
        <xml>
          <x:ExcelWorkbook>
            <x:ExcelWorksheets>
              <x:ExcelWorksheet>
                <x:Name>KBM Baru Cirebon</x:Name>
                <x:WorksheetOptions>
                  <x:DisplayGridlines/>
                </x:WorksheetOptions>
              </x:ExcelWorksheet>
            </x:ExcelWorksheets>
          </x:ExcelWorkbook>
        </xml>
        <![endif]-->
      </head>
      <body>
        <div style="font-family: Arial, sans-serif; padding: 16px;">
          <h2 style="color: #1e3a8a; margin-bottom: 4px;">P3DW SAMSAT KOTA CIREBON</h2>
          <h3 style="color: #334155; margin-top: 0;">REKAP ARSIP KENDARAAN BERMOTOR BARU (KBM BARU)</h3>
          <p style="color: #64748b; font-size: 12px;">Tanggal Cetak: ${new Date().toLocaleString('id-ID')} | Total Data: ${records.length} Berkas</p>
          <table border="1" cellpadding="6" cellspacing="0" style="border-collapse: collapse; width: 100%; font-size: 13px;">
            <thead>
              <tr style="background-color: #1e3a8a; color: #ffffff;">
                <th>No</th>
                <th>TGL Entri</th>
                <th>NOPOL</th>
                <th>NAMA Pemilik</th>
                <th>TGL Faktur</th>
                <th>TGL Bayar</th>
                <th>JATEM Faktur</th>
                <th>RODA</th>
                <th>TRANSAKSI</th>
                <th>PLAT</th>
                <th>Status Bayar</th>
                <th>Link Folder PC</th>
                <th>Catatan / Reasoning</th>
              </tr>
            </thead>
            <tbody>
              ${tableRows}
            </tbody>
          </table>
        </div>
      </body>
    </html>
  `;

  const blob = new Blob([excelHtml], { type: 'application/vnd.ms-excel;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${filenamePrefix}_${getTodayDateString()}.xls`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function getEvidentImageUrl(record: KbmRecord): string {
  if (record.evident && record.evident.trim().length > 0) {
    return record.evident;
  }
  
  // Generate realistic document SVG evident preview
  const isPaid = record.statusBayar === 'SUDAH BAYAR';
  const stampColor = isPaid ? '#16a34a' : '#dc2626';
  const stampText = isPaid ? 'LUNAS / DIVERIFIKASI' : 'TERTUNDA PENETAPAN';

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="420" viewBox="0 0 600 420">
    <defs>
      <linearGradient id="paper" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#f8fafc"/>
        <stop offset="100%" stop-color="#f1f5f9"/>
      </linearGradient>
      <pattern id="lines" width="40" height="20" patternUnits="userSpaceOnUse">
        <line x1="0" y1="20" x2="40" y2="20" stroke="#cbd5e1" stroke-width="0.5" stroke-dasharray="2 2"/>
      </pattern>
    </defs>
    <!-- Background Card -->
    <rect width="600" height="420" rx="12" fill="url(#paper)" stroke="#94a3b8" stroke-width="2"/>
    <rect x="15" y="15" width="570" height="390" rx="8" fill="none" stroke="#cbd5e1" stroke-width="1"/>
    
    <!-- Header -->
    <rect x="15" y="15" width="570" height="60" rx="8" fill="#1e293b"/>
    <text x="35" y="42" font-family="Arial, sans-serif" font-size="14" font-weight="bold" fill="#f59e0b" letter-spacing="1">DOKUMEN EVIDENT ARSIP FAKTUR KBM BARU</text>
    <text x="35" y="60" font-family="Arial, sans-serif" font-size="11" fill="#cbd5e1">P3DW SAMSAT KOTA CIREBON · BAPENDA JAWA BARAT</text>
    
    <!-- Watermark / Shield -->
    <circle cx="300" cy="240" r="85" fill="#f1f5f9" stroke="#e2e8f0" stroke-width="2"/>
    <text x="300" y="235" font-family="Arial, sans-serif" font-size="14" font-weight="bold" fill="#94a3b8" text-anchor="middle">SAMSAT KOTA CIREBON</text>
    <text x="300" y="255" font-family="Arial, sans-serif" font-size="11" fill="#94a3b8" text-anchor="middle">ARSIP RESMI TERVERIFIKASI</text>

    <!-- Document Fields -->
    <g transform="translate(40, 105)" font-family="Arial, monospace" font-size="12">
      <!-- Row 1 -->
      <text x="0" y="0" font-weight="bold" fill="#475569">NOMOR POLISI</text>
      <text x="180" y="0" font-weight="bold" fill="#0f172a" font-size="15">: ${record.nopol}</text>
      
      <!-- Row 2 -->
      <text x="0" y="30" font-weight="bold" fill="#475569">NAMA PEMILIK</text>
      <text x="180" y="30" font-weight="bold" fill="#0f172a">: ${record.nama.slice(0, 32)}</text>
      
      <!-- Row 3 -->
      <text x="0" y="60" font-weight="bold" fill="#475569">TANGGAL FAKTUR</text>
      <text x="180" y="60" fill="#0f172a">: ${record.tglFaktur} (Jatem: ${record.jatemFakt})</text>
      
      <!-- Row 4 -->
      <text x="0" y="90" font-weight="bold" fill="#475569">KLASIFIKASI KBM</text>
      <text x="180" y="90" fill="#0f172a">: ${record.roda} · Transaksi ${record.transaksi} · Plat ${record.plat}</text>
      
      <!-- Row 5 -->
      <text x="0" y="120" font-weight="bold" fill="#475569">TANGGAL BAYAR</text>
      <text x="180" y="120" font-weight="bold" fill="${isPaid ? '#166534' : '#991b1b'}">: ${record.tglBayar || 'BELUM DIBAYAR DI KASIR'}</text>

      <!-- Row 6 -->
      <text x="0" y="150" font-weight="bold" fill="#475569">BERKAS LOKAL PC</text>
      <text x="180" y="150" fill="#0369a1" font-size="11">: ${record.linkFile ? record.linkFile.slice(0, 36) + '...' : '-'}</text>

      <!-- Row 7 -->
      <text x="0" y="180" font-weight="bold" fill="#475569">CATATAN PETUGAS</text>
      <text x="180" y="180" fill="#334155" font-size="11" font-style="italic">: ${record.note ? record.note.slice(0, 40) + '...' : '-'}</text>
    </g>

    <!-- Official Verification Stamp -->
    <g transform="translate(420, 290) rotate(-8)">
      <rect x="-10" y="-5" width="160" height="55" rx="6" fill="none" stroke="${stampColor}" stroke-width="3" stroke-dasharray="6 3"/>
      <text x="70" y="18" font-family="Arial, sans-serif" font-size="10" font-weight="bold" fill="${stampColor}" text-anchor="middle">PETUGAS PENETAPAN</text>
      <text x="70" y="36" font-family="Arial, sans-serif" font-size="12" font-weight="black" fill="${stampColor}" text-anchor="middle">${stampText}</text>
    </g>

    <!-- Footer Bar -->
    <line x1="30" y1="385" x2="570" y2="385" stroke="#94a3b8" stroke-width="1"/>
    <text x="40" y="402" font-family="Arial, sans-serif" font-size="10" fill="#64748b">ID Berkas: ${record.id} · Kode Wilayah: P3DW Kota Cirebon (Samsat)</text>
    <text x="560" y="402" font-family="Arial, sans-serif" font-size="10" fill="#64748b" text-anchor="end">Evident File: ${record.evidentName || 'FAKTUR_DIGITAL.PDF'}</text>
  </svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}
